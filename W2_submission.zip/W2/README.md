# W2：补充联邦学习基线

本目录补充四类基线：Local-only、Random Partial FedAvg、FedProx 和不平衡学习。W1 文件保持不变，W2 使用复制后且哈希一致的数据进行独立实验。

详细公平性约束见 `EXPERIMENT_PROTOCOL.md`。

实验结果和解读见 `RESULTS_SUMMARY.md`。

## 环境

本项目使用 `uv` 管理 Python、虚拟环境、依赖和锁文件：

```bash
cd code/w2
uv sync --frozen
```

依赖声明在 `pyproject.toml`，精确解析版本记录在 `uv.lock`。

## 一键运行

```bash
uv run --frozen python src/run_all_baselines.py
```

## 分别运行

```bash
uv run --frozen python src/train_local_only_baseline.py
uv run --frozen python src/train_random_partial_fedavg.py
uv run --frozen python src/train_fedprox_baseline.py
uv run --frozen python src/train_imbalance_baselines.py
uv run --frozen python src/build_comparison_report.py
```

## 默认实验定义

- Local-only：每个工厂独立训练250个 epoch，使用本地验证集选择阈值，再在该工厂测试样本上预测；最终汇总所有工厂的测试预测。
- Random Partial FedAvg：每轮从5个客户端中固定随机选择3个，50轮，每轮本地训练5个 epoch。
- FedProx：5个客户端全部参与，50轮，每轮本地训练5个 epoch，`mu=0.01`。
- 不平衡学习：集中式比较 Unweighted BCE、Class-weighted BCE、Random Oversampling 和 Focal Loss。

## 主要输出

- `reports/local_only_summary_results.csv`
- `reports/random_partial_fedavg_results.csv`
- `reports/fedprox_results.csv`
- `reports/imbalance_baseline_results.csv`
- `reports/all_baseline_comparison.csv`
- `reports/fairness_audit.json`
- `figures/all_baseline_f1_comparison.png`
- `models/*.json`

训练历史和阈值搜索明细也保存在 `reports/` 中。
