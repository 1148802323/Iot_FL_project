# W2 Fair Experiment Protocol

## Fixed across all methods

- Dataset: the unchanged W1 `ai4i_clean_standardized.csv`.
- Client partitions: the unchanged W1 IID, Moderate Non-IID and Highly Non-IID CSV files.
- Split: stratified 60% train, 20% validation and 20% test with seed 42, matching W1 exactly.
- Features: the same ten leakage-safe feature columns used in W1.
- Optimizer: full-batch gradient descent with learning rate 0.08 and L2 coefficient 0.001.
- Evaluation: Accuracy, Precision, Recall and F1 on held-out test samples.
- Threshold: selected only on validation samples by the same 0.05–0.95 F1 sweep used in W1.
- Test data is never oversampled, reweighted or used for threshold selection.

## Method-specific changes

- Local-only changes only the collaboration mode: each factory trains and deploys its own model. Each client receives 250 local epochs, equal to 50 FedAvg rounds × 5 local epochs.
- Random Partial FedAvg changes only client participation: 3 of 5 clients are selected uniformly without replacement per round. It keeps 50 rounds and 5 local epochs, so it intentionally uses 40% fewer client communications than full FedAvg.
- FedProx changes only the local objective by adding a proximal penalty with `mu=0.01`. All 5 clients still participate for 50 rounds.
- Imbalance baselines use the same centralized split and compare unweighted BCE, class-weighted BCE, random oversampling and focal loss. Oversampling touches training data only.

## Interpretation constraint

Random Partial FedAvg is round-matched, not client-update-matched: 150 client updates versus 250 for full FedAvg. This is intentional for measuring the performance/communication trade-off and must be stated when results are compared.

W2 deliberately inherits the existing W1 processed data and client partitions. It does not repair or redefine the Moderate Non-IID partition, because doing so would change the dataset underneath the comparison.
