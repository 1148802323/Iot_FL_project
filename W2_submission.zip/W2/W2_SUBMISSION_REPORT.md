# W2 Baseline Experiment Report

## 1. 本周完成内容

这周我在 W1 的基础上补充了四类实验：Local-only、Random Partial FedAvg、FedProx，以及针对类别不平衡的训练方法。

为了保证对比公平，所有实验都使用 W1 预处理后的同一份数据、相同的客户端划分、相同的训练/验证/测试样本和相同的10个输入特征。分类阈值只在验证集上选择，测试集没有参与训练和调参。

## 2. 完成的基线

| 基线 | 简单说明 |
|---|---|
| Local-only | 每个工厂独立训练和使用自己的模型，不进行联邦聚合 |
| Random Partial FedAvg | 每轮从5个客户端中随机选择3个参加训练 |
| FedProx | 在FedAvg本地目标中加入近端约束，`mu=0.01` |
| 不平衡学习 | 比较Unweighted BCE、Class-weighted BCE、Random Oversampling和Focal Loss |

## 3. 主要结果

### 3.1 联邦和本地基线F1

| 方法 | IID | Moderate Non-IID | Highly Non-IID | 客户端更新次数 |
|---|---:|---:|---:|---:|
| W1 Standard FedAvg | 0.3567 | 0.3676 | 0.3235 | 250 |
| Local-only | 0.3356 | 0.3259 | 0.4595 | 0 |
| Random Partial FedAvg | 0.3576 | 0.3415 | 0.3303 | 150 |
| FedProx | 0.3567 | 0.3676 | 0.3235 | 250 |

Random Partial FedAvg把客户端更新次数从250次降到了150次，减少了40%的客户端通信。在IID和Highly Non-IID数据上，它的F1与完整FedAvg比较接近。

FedProx在当前逻辑回归模型和参数设置下，与标准FedAvg的结果相同。这说明在目前这个较简单的凸模型实验中，近端项没有带来明显提升。

Local-only在Highly Non-IID上的F1较高，是因为每个工厂使用自己的模型和本地阈值，体现的是本地模型的专业化效果，不代表一个共享全局模型取得了更好的结果。

### 3.2 类别不平衡实验

| 方法 | Precision | Recall | F1 |
|---|---:|---:|---:|
| Unweighted BCE | 0.2857 | 0.3235 | 0.3034 |
| Class-weighted BCE | 0.3256 | 0.4118 | 0.3636 |
| Random Oversampling | 0.3256 | 0.4118 | 0.3636 |
| Focal Loss | 0.2899 | 0.2941 | 0.2920 |

Class-weighted BCE和Random Oversampling取得了本组实验中最好的F1。Class-weighted BCE也成功复现了W1的集中式加权逻辑回归结果。

## 4. 简单总结

本周补充的基线都已经完成并能够重复运行。公平性检查已经通过，连续两次运行得到的输出也完全一致。目前看，随机选择部分客户端可以减少通信，同时保持比较接近的模型表现；类别权重仍然是当前数据上较有效且简单的不平衡处理方法。

后续如果继续实验，我认为可以增加多个随机种子，并重点比较不同客户端选择方法在Highly Non-IID情况下的稳定性。

## 5. 运行方式

```bash
uv sync --frozen
uv run --frozen python src/run_all_baselines.py
```
