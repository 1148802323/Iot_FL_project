from __future__ import annotations

from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont


REPORTS = Path("reports")
REFERENCE = Path("reference/w1_results")
FIGURES = Path("figures")


def normalized_row(
    *,
    family: str,
    method: str,
    strategy: str,
    row: pd.Series,
    source: str,
    client_updates: int | str = "",
    sample_updates: int | str = "",
) -> dict[str, object]:
    return {
        "family": family,
        "method": method,
        "strategy": strategy,
        "accuracy": row["accuracy"],
        "precision": row["precision"],
        "recall": row["recall"],
        "f1": row["f1"],
        "tp": row["tp"],
        "tn": row["tn"],
        "fp": row["fp"],
        "fn": row["fn"],
        "communication_client_updates": client_updates,
        "communication_sample_updates": sample_updates,
        "source": source,
    }


def load_rows() -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []

    central = pd.read_csv(REFERENCE / "centralized_baseline_results.csv")
    for _, row in central[central["split"] == "test"].iterrows():
        rows.append(
            normalized_row(
                family="W1 reference",
                method=str(row["model"]),
                strategy="centralized",
                row=row,
                source="W1 centralized_baseline_results.csv",
            )
        )

    fedavg = pd.read_csv(REFERENCE / "fedavg_baseline_results.csv")
    for _, row in fedavg.iterrows():
        rows.append(
            normalized_row(
                family="W1 reference",
                method="Standard FedAvg",
                strategy=str(row["strategy"]),
                row=row,
                client_updates=int(row["communication_client_updates"]),
                sample_updates=int(row["communication_sample_updates"]),
                source="W1 fedavg_baseline_results.csv",
            )
        )

    imbalance = pd.read_csv(REPORTS / "imbalance_baseline_results.csv")
    for _, row in imbalance.iterrows():
        rows.append(
            normalized_row(
                family="Imbalance learning",
                method=str(row["method"]),
                strategy="centralized",
                row=row,
                source="imbalance_baseline_results.csv",
            )
        )

    local = pd.read_csv(REPORTS / "local_only_summary_results.csv")
    for _, row in local.iterrows():
        rows.append(
            normalized_row(
                family="Local-only",
                method="Local-only pooled deployment",
                strategy=str(row["strategy"]),
                row=row,
                client_updates=0,
                sample_updates=0,
                source="local_only_summary_results.csv",
            )
        )

    partial = pd.read_csv(REPORTS / "random_partial_fedavg_results.csv")
    for _, row in partial.iterrows():
        rows.append(
            normalized_row(
                family="Federated",
                method="Random Partial FedAvg",
                strategy=str(row["strategy"]),
                row=row,
                client_updates=int(row["communication_client_updates"]),
                sample_updates=int(row["communication_sample_updates"]),
                source="random_partial_fedavg_results.csv",
            )
        )

    fedprox = pd.read_csv(REPORTS / "fedprox_results.csv")
    for _, row in fedprox.iterrows():
        rows.append(
            normalized_row(
                family="Federated",
                method="FedProx (mu=0.01)",
                strategy=str(row["strategy"]),
                row=row,
                client_updates=int(row["communication_client_updates"]),
                sample_updates=int(row["communication_sample_updates"]),
                source="fedprox_results.csv",
            )
        )
    return rows


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_f1_chart(table: pd.DataFrame, out_path: Path) -> None:
    ordered = table.sort_values("f1", ascending=True).reset_index(drop=True)
    width = 1500
    row_height = 48
    height = 170 + row_height * len(ordered)
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    draw.text((55, 30), "W1 + W2 Baseline Test F1 Comparison", fill=(28, 35, 39), font=font(34, True))
    left, right, top = 500, 1420, 115
    colors = {
        "W1 reference": (41, 98, 120),
        "Imbalance learning": (42, 157, 143),
        "Local-only": (130, 90, 160),
        "Federated": (225, 111, 86),
    }
    for index, row in ordered.iterrows():
        y = top + index * row_height
        label = f"{row['method']} | {str(row['strategy']).replace('_', ' ')}"
        draw.text((35, y + 7), label, fill=(28, 35, 39), font=font(17))
        bar_end = left + float(row["f1"]) * (right - left)
        draw.rounded_rectangle((left, y + 5, bar_end, y + 35), radius=6, fill=colors[str(row["family"])])
        draw.text((bar_end + 10, y + 7), f"{float(row['f1']):.4f}", fill=(28, 35, 39), font=font(17, True))
    draw.line((left, top - 12, left, height - 35), fill=(100, 108, 112), width=2)
    image.save(out_path)


def main() -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame(load_rows())
    table.to_csv(REPORTS / "all_baseline_comparison.csv", index=False)
    draw_f1_chart(table, FIGURES / "all_baseline_f1_comparison.png")
    print("Combined comparison report complete.")
    print(table[["family", "method", "strategy", "accuracy", "precision", "recall", "f1"]].to_string(index=False))


if __name__ == "__main__":
    main()
