from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from baseline_common import (
    FEATURES,
    STRATEGIES,
    STRATEGY_SEED_OFFSETS,
    TARGET,
    aggregate_weighted,
    load_training_clients,
    metrics,
    model_payload,
    predict_proba,
    split_ids,
    train_logistic,
    tune_threshold,
    validate_dataset,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run random partial-participation FedAvg.")
    parser.add_argument("--data", type=Path, default=Path("data/processed/ai4i_clean_standardized.csv"))
    parser.add_argument("--factory-root", type=Path, default=Path("data/factories"))
    parser.add_argument("--reports", type=Path, default=Path("reports"))
    parser.add_argument("--models", type=Path, default=Path("models"))
    parser.add_argument("--rounds", type=int, default=50)
    parser.add_argument("--local-epochs", type=int, default=5)
    parser.add_argument("--clients-per-round", type=int, default=3)
    parser.add_argument("--lr", type=float, default=0.08)
    parser.add_argument("--l2", type=float, default=0.001)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    args.reports.mkdir(parents=True, exist_ok=True)
    args.models.mkdir(parents=True, exist_ok=True)
    full = pd.read_csv(args.data)
    validate_dataset(full)
    train_ids, val_ids, test_ids = split_ids(full, args.seed)
    val = full[full["UDI"].isin(val_ids)]
    test = full[full["UDI"].isin(test_ids)]
    x_val = val[FEATURES].to_numpy(dtype=float)
    y_val = val[TARGET].to_numpy(dtype=int)
    x_test = test[FEATURES].to_numpy(dtype=float)
    y_test = test[TARGET].to_numpy(dtype=int)

    history_rows: list[dict[str, object]] = []
    threshold_tables: list[pd.DataFrame] = []
    result_rows: list[dict[str, object]] = []
    models: dict[str, object] = {}

    for strategy in STRATEGIES:
        clients = load_training_clients(args.factory_root, strategy, train_ids)
        if not 1 <= args.clients_per_round <= len(clients):
            raise ValueError("clients-per-round must be between 1 and the total client count.")
        rng = np.random.default_rng(args.seed + STRATEGY_SEED_OFFSETS[strategy])
        global_w = np.zeros(len(FEATURES) + 1, dtype=float)
        participation = {str(client["name"]): 0 for client in clients}
        sample_updates = 0

        for round_num in range(1, args.rounds + 1):
            chosen_idx = rng.choice(len(clients), size=args.clients_per_round, replace=False)
            chosen = [clients[int(i)] for i in chosen_idx]
            local_models: list[tuple[np.ndarray, int]] = []
            local_losses: list[float] = []
            selected_names: list[str] = []
            round_samples = 0
            for client in chosen:
                local_w, local_history = train_logistic(
                    client["x"],  # type: ignore[arg-type]
                    client["y"],  # type: ignore[arg-type]
                    lr=args.lr,
                    epochs=args.local_epochs,
                    l2=args.l2,
                    loss_mode="class_weighted",
                    initial=global_w,
                    history_interval=args.local_epochs,
                )
                rows = int(client["rows"])
                name = str(client["name"])
                local_models.append((local_w, rows))
                local_losses.append(float(local_history.iloc[-1]["objective_loss"]))
                selected_names.append(name)
                participation[name] += 1
                round_samples += rows
            global_w = aggregate_weighted(local_models)
            sample_updates += round_samples

            val_metrics = metrics(y_val, predict_proba(x_val, global_w), 0.5)
            test_metrics = metrics(y_test, predict_proba(x_test, global_w), 0.5)
            history_rows.append(
                {
                    "strategy": strategy,
                    "round": round_num,
                    "selected_clients": ";".join(selected_names),
                    "participating_clients": len(chosen),
                    "round_samples": round_samples,
                    "mean_client_loss": round(float(np.mean(local_losses)), 6),
                    "val_accuracy": val_metrics["accuracy"],
                    "val_precision": val_metrics["precision"],
                    "val_recall": val_metrics["recall"],
                    "val_f1": val_metrics["f1"],
                    "test_accuracy_at_0_5": test_metrics["accuracy"],
                    "test_precision_at_0_5": test_metrics["precision"],
                    "test_recall_at_0_5": test_metrics["recall"],
                    "test_f1_at_0_5": test_metrics["f1"],
                }
            )

        val_prob = predict_proba(x_val, global_w)
        threshold, threshold_table = tune_threshold(y_val, val_prob)
        threshold_table.insert(0, "strategy", strategy)
        threshold_tables.append(threshold_table)
        final_metrics = metrics(y_test, predict_proba(x_test, global_w), threshold)
        result_rows.append(
            {
                "strategy": strategy,
                "method": "Random Partial FedAvg",
                "rounds": args.rounds,
                "local_epochs": args.local_epochs,
                "total_clients": len(clients),
                "clients_per_round": args.clients_per_round,
                "participation_rate": round(args.clients_per_round / len(clients), 4),
                "train_samples": sum(int(client["rows"]) for client in clients),
                **final_metrics,
                "communication_client_updates": args.rounds * args.clients_per_round,
                "communication_sample_updates": sample_updates,
            }
        )
        payload = model_payload(global_w)
        payload.update(
            {
                "method": "random_partial_fedavg_class_weighted_logistic_regression",
                "strategy": strategy,
                "threshold": threshold,
                "rounds": args.rounds,
                "local_epochs": args.local_epochs,
                "clients_per_round": args.clients_per_round,
                "participation_counts": participation,
                "seed": args.seed + STRATEGY_SEED_OFFSETS[strategy],
            }
        )
        models[strategy] = payload

    pd.DataFrame(history_rows).to_csv(
        args.reports / "random_partial_fedavg_training_history.csv", index=False
    )
    pd.concat(threshold_tables, ignore_index=True).to_csv(
        args.reports / "random_partial_fedavg_threshold_tuning.csv", index=False
    )
    pd.DataFrame(result_rows).to_csv(
        args.reports / "random_partial_fedavg_results.csv", index=False
    )
    write_json(args.models / "random_partial_fedavg_models.json", models)
    print("Random Partial FedAvg baseline complete.")
    print(pd.DataFrame(result_rows).to_string(index=False))


if __name__ == "__main__":
    main()
