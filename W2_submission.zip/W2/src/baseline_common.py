from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


TARGET = "Machine failure"
ID_COL = "UDI"
FEATURES = [
    "air_temperature_k_z",
    "process_temperature_k_z",
    "rotational_speed_rpm_z",
    "torque_nm_z",
    "tool_wear_min_z",
    "temperature_gap_k_z",
    "power_proxy_z",
    "Type_H",
    "Type_L",
    "Type_M",
]
STRATEGIES = ["iid", "moderate_non_iid", "highly_non_iid"]
STRATEGY_SEED_OFFSETS = {"iid": 0, "moderate_non_iid": 10_000, "highly_non_iid": 20_000}


def sigmoid(z: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(z, -40, 40)))


def add_intercept(x: np.ndarray) -> np.ndarray:
    return np.column_stack([np.ones(len(x)), x])


def stratified_split(
    y: np.ndarray,
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Match the W1 split implementation exactly."""
    rng = np.random.default_rng(seed)
    train_idx: list[int] = []
    val_idx: list[int] = []
    test_idx: list[int] = []
    for label in np.unique(y):
        idx = np.where(y == label)[0].copy()
        rng.shuffle(idx)
        n_train = int(round(len(idx) * train_ratio))
        n_val = int(round(len(idx) * val_ratio))
        train_idx.extend(idx[:n_train].tolist())
        val_idx.extend(idx[n_train : n_train + n_val].tolist())
        test_idx.extend(idx[n_train + n_val :].tolist())
    for arr in (train_idx, val_idx, test_idx):
        rng.shuffle(arr)
    return np.array(train_idx), np.array(val_idx), np.array(test_idx)


def split_ids(full: pd.DataFrame, seed: int) -> tuple[set[int], set[int], set[int]]:
    train_idx, val_idx, test_idx = stratified_split(
        full[TARGET].to_numpy(dtype=int), 0.6, 0.2, seed
    )
    return (
        set(full.loc[train_idx, ID_COL].astype(int)),
        set(full.loc[val_idx, ID_COL].astype(int)),
        set(full.loc[test_idx, ID_COL].astype(int)),
    )


def validate_dataset(full: pd.DataFrame) -> None:
    missing = [column for column in [ID_COL, TARGET, *FEATURES] if column not in full.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if full[ID_COL].duplicated().any():
        raise ValueError(f"{ID_COL} must be unique for a fair shared split.")


def sample_weights(y: np.ndarray) -> np.ndarray:
    pos = float(y.sum())
    neg = float((y == 0).sum())
    if pos == 0 or neg == 0:
        return np.ones(len(y), dtype=float)
    return np.where(y == 1, len(y) / (2 * pos), len(y) / (2 * neg))


def weighted_log_loss(y: np.ndarray, p: np.ndarray, weights: np.ndarray) -> float:
    eps = 1e-8
    loss = -(y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps))
    return float(np.average(loss, weights=weights))


def focal_loss(
    y: np.ndarray,
    p: np.ndarray,
    alpha: float,
    gamma: float,
) -> float:
    eps = 1e-8
    clipped = np.clip(p, eps, 1 - eps)
    pt = np.where(y == 1, clipped, 1 - clipped)
    alpha_t = np.where(y == 1, alpha, 1 - alpha)
    return float(np.mean(-alpha_t * np.power(1 - pt, gamma) * np.log(pt)))


def train_logistic(
    x: np.ndarray,
    y: np.ndarray,
    *,
    lr: float,
    epochs: int,
    l2: float,
    loss_mode: str = "class_weighted",
    initial: np.ndarray | None = None,
    prox_center: np.ndarray | None = None,
    prox_mu: float = 0.0,
    focal_alpha: float = 0.75,
    focal_gamma: float = 2.0,
    history_interval: int = 25,
) -> tuple[np.ndarray, pd.DataFrame]:
    if len(x) == 0:
        raise ValueError("Cannot train on an empty dataset.")
    xb = add_intercept(x)
    w = np.zeros(xb.shape[1], dtype=float) if initial is None else initial.astype(float).copy()
    if prox_center is not None and prox_center.shape != w.shape:
        raise ValueError("prox_center and model parameters must have the same shape.")

    if loss_mode == "class_weighted":
        weights = sample_weights(y)
    elif loss_mode == "unweighted":
        weights = np.ones(len(y), dtype=float)
    elif loss_mode == "focal":
        weights = np.ones(len(y), dtype=float)
    else:
        raise ValueError(f"Unsupported loss mode: {loss_mode}")

    history_rows = []
    for epoch in range(1, epochs + 1):
        p = sigmoid(xb @ w)
        if loss_mode == "focal":
            eps = 1e-8
            clipped = np.clip(p, eps, 1 - eps)
            pt = np.where(y == 1, clipped, 1 - clipped)
            alpha_t = np.where(y == 1, focal_alpha, 1 - focal_alpha)
            modulation = np.power(1 - pt, focal_gamma)
            correction = focal_gamma * pt * np.power(1 - pt, focal_gamma - 1) * np.log(pt)
            grad_z = alpha_t * (p - y) * (modulation - correction)
            grad = (xb.T @ grad_z) / len(y)
            objective = focal_loss(y, p, focal_alpha, focal_gamma)
        else:
            grad = (xb.T @ ((p - y) * weights)) / len(y)
            objective = weighted_log_loss(y, p, weights)

        grad[1:] += l2 * w[1:]
        objective += 0.5 * l2 * float(np.dot(w[1:], w[1:]))
        if prox_center is not None and prox_mu > 0:
            delta = w - prox_center
            grad += prox_mu * delta
            objective += 0.5 * prox_mu * float(np.dot(delta, delta))
        w -= lr * grad

        if epoch == 1 or epoch % history_interval == 0 or epoch == epochs:
            history_rows.append(
                {
                    "epoch": epoch,
                    "objective_loss": float(objective),
                    "mean_probability": float(p.mean()),
                }
            )
    return w, pd.DataFrame(history_rows)


def predict_proba(x: np.ndarray, weights: np.ndarray) -> np.ndarray:
    return sigmoid(add_intercept(x) @ weights)


def metrics_from_predictions(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float | int]:
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    accuracy = (tp + tn) / max(len(y_true), 1)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    return {
        "accuracy": round(float(accuracy), 4),
        "precision": round(float(precision), 4),
        "recall": round(float(recall), 4),
        "f1": round(float(f1), 4),
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "positive_predictions": int(y_pred.sum()),
    }


def metrics(y_true: np.ndarray, y_prob: np.ndarray, threshold: float) -> dict[str, float | int]:
    result = {"threshold": round(float(threshold), 4)}
    result.update(metrics_from_predictions(y_true, (y_prob >= threshold).astype(int)))
    return result


def tune_threshold(y_true: np.ndarray, y_prob: np.ndarray) -> tuple[float, pd.DataFrame]:
    rows = [metrics(y_true, y_prob, float(t)) for t in np.linspace(0.05, 0.95, 91)]
    table = pd.DataFrame(rows)
    best = table.sort_values(["f1", "recall", "precision"], ascending=False).iloc[0]
    return float(best["threshold"]), table


def oversample_binary(
    x: np.ndarray,
    y: np.ndarray,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Randomly oversample the minority class to the majority count using training data only."""
    rng = np.random.default_rng(seed)
    zero_idx = np.where(y == 0)[0]
    one_idx = np.where(y == 1)[0]
    if len(zero_idx) == 0 or len(one_idx) == 0:
        return x.copy(), y.copy()
    majority_idx, minority_idx = (zero_idx, one_idx) if len(zero_idx) >= len(one_idx) else (one_idx, zero_idx)
    sampled_minority = rng.choice(minority_idx, size=len(majority_idx), replace=True)
    combined = np.concatenate([majority_idx, sampled_minority])
    rng.shuffle(combined)
    return x[combined], y[combined]


def load_training_clients(
    factory_root: Path,
    strategy: str,
    train_ids: set[int],
) -> list[dict[str, object]]:
    clients: list[dict[str, object]] = []
    for path in sorted((factory_root / strategy).glob("factory_*.csv")):
        frame = pd.read_csv(path)
        train = frame[frame[ID_COL].isin(train_ids)].copy()
        if train.empty:
            continue
        clients.append(
            {
                "name": path.stem,
                "rows": len(train),
                "failure_rate": float(train[TARGET].mean()),
                "x": train[FEATURES].to_numpy(dtype=float),
                "y": train[TARGET].to_numpy(dtype=int),
            }
        )
    if not clients:
        raise ValueError(f"No clients found for {strategy}.")
    return clients


def aggregate_weighted(client_models: list[tuple[np.ndarray, int]]) -> np.ndarray:
    total = sum(rows for _, rows in client_models)
    if total <= 0:
        raise ValueError("Cannot aggregate client models without samples.")
    return sum(weights * (rows / total) for weights, rows in client_models)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def model_payload(weights: np.ndarray) -> dict[str, object]:
    return {
        "features": FEATURES,
        "intercept": float(weights[0]),
        "coefficients": {
            feature: float(value) for feature, value in zip(FEATURES, weights[1:])
        },
    }
