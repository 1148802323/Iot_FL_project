from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from baseline_common import (
    FEATURES,
    STRATEGIES,
    TARGET,
    aggregate_weighted,
    load_training_clients,
    metrics,
    model_payload,
    predict_proba,
    split_ids,
    train_logistic,
    tune_threshold,
    validate_dataset,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an all-client FedProx baseline.")
    parser.add_argument("--data", type=Path, default=Path("data/processed/ai4i_clean_standardized.csv"))
    parser.add_argument("--factory-root", type=Path, default=Path("data/factories"))
    parser.add_argument("--reports", type=Path, default=Path("reports"))
    parser.add_argument("--models", type=Path, default=Path("models"))
    parser.add_argument("--rounds", type=int, default=50)
    parser.add_argument("--local-epochs", type=int, default=5)
    parser.add_argument("--lr", type=float, default=0.08)
    parser.add_argument("--l2", type=float, default=0.001)
    parser.add_argument("--mu", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    args.reports.mkdir(parents=True, exist_ok=True)
    args.models.mkdir(parents=True, exist_ok=True)
    full = pd.read_csv(args.data)
    validate_dataset(full)
    train_ids, val_ids, test_ids = split_ids(full, args.seed)
    val = full[full["UDI"].isin(val_ids)]
    test = full[full["UDI"].isin(test_ids)]
    x_val = val[FEATURES].to_numpy(dtype=float)
    y_val = val[TARGET].to_numpy(dtype=int)
    x_test = test[FEATURES].to_numpy(dtype=float)
    y_test = test[TARGET].to_numpy(dtype=int)

    history_rows: list[dict[str, object]] = []
    threshold_tables: list[pd.DataFrame] = []
    result_rows: list[dict[str, object]] = []
    models: dict[str, object] = {}

    for strategy in STRATEGIES:
        clients = load_training_clients(args.factory_root, strategy, train_ids)
        global_w = np.zeros(len(FEATURES) + 1, dtype=float)
        total_rows = sum(int(client["rows"]) for client in clients)

        for round_num in range(1, args.rounds + 1):
            local_models: list[tuple[np.ndarray, int]] = []
            local_losses: list[float] = []
            for client in clients:
                local_w, local_history = train_logistic(
                    client["x"],  # type: ignore[arg-type]
                    client["y"],  # type: ignore[arg-type]
                    lr=args.lr,
                    epochs=args.local_epochs,
                    l2=args.l2,
                    loss_mode="class_weighted",
                    initial=global_w,
                    prox_center=global_w,
                    prox_mu=args.mu,
                    history_interval=args.local_epochs,
                )
                local_models.append((local_w, int(client["rows"])))
                local_losses.append(float(local_history.iloc[-1]["objective_loss"]))
            global_w = aggregate_weighted(local_models)

            val_metrics = metrics(y_val, predict_proba(x_val, global_w), 0.5)
            test_metrics = metrics(y_test, predict_proba(x_test, global_w), 0.5)
            history_rows.append(
                {
                    "strategy": strategy,
                    "round": round_num,
                    "participating_clients": len(clients),
                    "local_epochs": args.local_epochs,
                    "client_samples": total_rows,
                    "proximal_mu": args.mu,
                    "mean_client_objective": round(float(np.mean(local_losses)), 6),
                    "val_accuracy": val_metrics["accuracy"],
                    "val_precision": val_metrics["precision"],
                    "val_recall": val_metrics["recall"],
                    "val_f1": val_metrics["f1"],
                    "test_accuracy_at_0_5": test_metrics["accuracy"],
                    "test_precision_at_0_5": test_metrics["precision"],
                    "test_recall_at_0_5": test_metrics["recall"],
                    "test_f1_at_0_5": test_metrics["f1"],
                }
            )

        val_prob = predict_proba(x_val, global_w)
        threshold, threshold_table = tune_threshold(y_val, val_prob)
        threshold_table.insert(0, "strategy", strategy)
        threshold_tables.append(threshold_table)
        final_metrics = metrics(y_test, predict_proba(x_test, global_w), threshold)
        result_rows.append(
            {
                "strategy": strategy,
                "method": "FedProx all clients",
                "rounds": args.rounds,
                "local_epochs": args.local_epochs,
                "clients": len(clients),
                "train_samples": total_rows,
                "proximal_mu": args.mu,
                **final_metrics,
                "communication_client_updates": args.rounds * len(clients),
                "communication_sample_updates": args.rounds * total_rows,
            }
        )
        payload = model_payload(global_w)
        payload.update(
            {
                "method": "fedprox_all_clients_class_weighted_logistic_regression",
                "strategy": strategy,
                "threshold": threshold,
                "rounds": args.rounds,
                "local_epochs": args.local_epochs,
                "proximal_mu": args.mu,
            }
        )
        models[strategy] = payload

    pd.DataFrame(history_rows).to_csv(args.reports / "fedprox_training_history.csv", index=False)
    pd.concat(threshold_tables, ignore_index=True).to_csv(
        args.reports / "fedprox_threshold_tuning.csv", index=False
    )
    pd.DataFrame(result_rows).to_csv(args.reports / "fedprox_results.csv", index=False)
    write_json(args.models / "fedprox_models.json", models)
    print("FedProx baseline complete.")
    print(pd.DataFrame(result_rows).to_string(index=False))


if __name__ == "__main__":
    main()
