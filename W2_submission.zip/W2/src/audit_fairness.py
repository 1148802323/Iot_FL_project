from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from baseline_common import ID_COL, STRATEGIES, TARGET, split_ids, validate_dataset


EXPECTED_CLEAN_SHA256 = "487ee2ff6e44104907b2492da5ad81e392eb2e94fde3d9998216fb6169a30ef3"
EXPECTED_PARTITION_SUMMARY_SHA256 = "82ef621a53956456c3fbbac668244cc646fb49a965ec381b1977193162b9ed83"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    data_path = Path("data/processed/ai4i_clean_standardized.csv")
    summary_path = Path("data/factories/factory_partition_summary.csv")
    full = pd.read_csv(data_path)
    validate_dataset(full)
    train_ids, val_ids, test_ids = split_ids(full, 42)

    checks: dict[str, object] = {
        "clean_data_sha256": sha256(data_path),
        "partition_summary_sha256": sha256(summary_path),
        "split_sizes": {"train": len(train_ids), "validation": len(val_ids), "test": len(test_ids)},
        "split_positive_counts": {
            "train": int(full[full[ID_COL].isin(train_ids)][TARGET].sum()),
            "validation": int(full[full[ID_COL].isin(val_ids)][TARGET].sum()),
            "test": int(full[full[ID_COL].isin(test_ids)][TARGET].sum()),
        },
    }
    check(checks["clean_data_sha256"] == EXPECTED_CLEAN_SHA256, "Processed data differs from W1.")
    check(
        checks["partition_summary_sha256"] == EXPECTED_PARTITION_SUMMARY_SHA256,
        "Factory partition summary differs from W1.",
    )
    check(len(train_ids) == 6000 and len(val_ids) == 2000 and len(test_ids) == 2000, "Split sizes changed.")
    check(not (train_ids & val_ids or train_ids & test_ids or val_ids & test_ids), "Shared splits overlap.")

    factory_checks: dict[str, object] = {}
    all_ids = set(full[ID_COL].astype(int))
    for strategy in STRATEGIES:
        files = sorted((Path("data/factories") / strategy).glob("factory_*.csv"))
        check(len(files) == 5, f"{strategy} must contain five clients.")
        seen: list[int] = []
        for path in files:
            seen.extend(pd.read_csv(path)[ID_COL].astype(int).tolist())
        check(len(seen) == len(set(seen)), f"{strategy} contains duplicate client assignments.")
        check(set(seen) == all_ids, f"{strategy} does not cover the same full dataset.")
        factory_checks[strategy] = {"clients": len(files), "rows": len(seen), "unique_ids": len(set(seen))}
    checks["factory_partitions"] = factory_checks

    w1 = pd.read_csv("reference/w1_results/centralized_baseline_results.csv")
    w1_row = w1[(w1["model"] == "Weighted Logistic Regression") & (w1["split"] == "test")].iloc[0]
    imbalance = pd.read_csv("reports/imbalance_baseline_results.csv")
    w2_row = imbalance[imbalance["method_key"] == "class_weighted_bce"].iloc[0]
    metric_columns = ["threshold", "accuracy", "precision", "recall", "f1", "tp", "tn", "fp", "fn"]
    check(
        all(float(w1_row[column]) == float(w2_row[column]) for column in metric_columns),
        "W2 class-weighted baseline does not reproduce W1.",
    )
    checks["w1_class_weighted_reproduced"] = True

    local = pd.read_csv("reports/local_only_summary_results.csv")
    check((local["test_samples"] == 2000).all(), "Local-only does not cover the shared test set.")
    partial = pd.read_csv("reports/random_partial_fedavg_results.csv")
    check((partial["communication_client_updates"] == 150).all(), "Partial FedAvg update budget changed.")
    check((partial["clients_per_round"] == 3).all(), "Partial FedAvg participation changed.")
    fedprox = pd.read_csv("reports/fedprox_results.csv")
    check((fedprox["communication_client_updates"] == 250).all(), "FedProx update budget differs from full FedAvg.")
    checks["communication_updates"] = {
        "local_only": 0,
        "random_partial_fedavg": 150,
        "standard_fedavg": 250,
        "fedprox": 250,
    }

    notebooks = [str(path) for path in Path(".").rglob("*.ipynb") if ".venv" not in path.parts]
    check(not notebooks, "W2 must not contain notebooks.")
    checks["notebooks"] = notebooks
    checks["status"] = "passed"

    out = Path("reports/fairness_audit.json")
    out.write_text(json.dumps(checks, indent=2), encoding="utf-8")
    print(f"Fairness audit passed: {out}")


if __name__ == "__main__":
    main()
