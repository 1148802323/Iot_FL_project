from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from baseline_common import (
    FEATURES,
    ID_COL,
    STRATEGIES,
    TARGET,
    metrics,
    metrics_from_predictions,
    model_payload,
    predict_proba,
    split_ids,
    train_logistic,
    tune_threshold,
    validate_dataset,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train one independent local model per factory.")
    parser.add_argument("--data", type=Path, default=Path("data/processed/ai4i_clean_standardized.csv"))
    parser.add_argument("--factory-root", type=Path, default=Path("data/factories"))
    parser.add_argument("--reports", type=Path, default=Path("reports"))
    parser.add_argument("--models", type=Path, default=Path("models"))
    parser.add_argument("--epochs", type=int, default=250)
    parser.add_argument("--lr", type=float, default=0.08)
    parser.add_argument("--l2", type=float, default=0.001)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    args.reports.mkdir(parents=True, exist_ok=True)
    args.models.mkdir(parents=True, exist_ok=True)
    full = pd.read_csv(args.data)
    validate_dataset(full)
    train_ids, val_ids, test_ids = split_ids(full, args.seed)

    client_rows: list[dict[str, object]] = []
    summary_rows: list[dict[str, object]] = []
    history_rows: list[pd.DataFrame] = []
    models: dict[str, dict[str, object]] = {}

    for strategy in STRATEGIES:
        strategy_predictions: list[np.ndarray] = []
        strategy_labels: list[np.ndarray] = []
        models[strategy] = {}
        train_total = val_total = test_total = 0

        for path in sorted((args.factory_root / strategy).glob("factory_*.csv")):
            frame = pd.read_csv(path)
            train = frame[frame[ID_COL].isin(train_ids)].copy()
            val = frame[frame[ID_COL].isin(val_ids)].copy()
            test = frame[frame[ID_COL].isin(test_ids)].copy()
            if train.empty or val.empty or test.empty:
                raise ValueError(f"{strategy}/{path.stem} has an empty shared split.")

            x_train = train[FEATURES].to_numpy(dtype=float)
            y_train = train[TARGET].to_numpy(dtype=int)
            weights, history = train_logistic(
                x_train,
                y_train,
                lr=args.lr,
                epochs=args.epochs,
                l2=args.l2,
                loss_mode="class_weighted",
            )
            history.insert(0, "client", path.stem)
            history.insert(0, "strategy", strategy)
            history_rows.append(history)

            y_val = val[TARGET].to_numpy(dtype=int)
            val_prob = predict_proba(val[FEATURES].to_numpy(dtype=float), weights)
            threshold, _ = tune_threshold(y_val, val_prob)

            y_test = test[TARGET].to_numpy(dtype=int)
            test_prob = predict_proba(test[FEATURES].to_numpy(dtype=float), weights)
            test_metrics = metrics(y_test, test_prob, threshold)
            client_rows.append(
                {
                    "strategy": strategy,
                    "client": path.stem,
                    "method": "Local-only class-weighted logistic regression",
                    "epochs": args.epochs,
                    "train_samples": len(train),
                    "validation_samples": len(val),
                    "test_samples": len(test),
                    "train_positives": int(y_train.sum()),
                    "validation_positives": int(y_val.sum()),
                    "test_positives": int(y_test.sum()),
                    **test_metrics,
                }
            )
            strategy_predictions.append((test_prob >= threshold).astype(int))
            strategy_labels.append(y_test)
            train_total += len(train)
            val_total += len(val)
            test_total += len(test)

            payload = model_payload(weights)
            payload.update(
                {
                    "method": "local_only_class_weighted_logistic_regression",
                    "strategy": strategy,
                    "client": path.stem,
                    "threshold": threshold,
                    "epochs": args.epochs,
                    "learning_rate": args.lr,
                    "l2": args.l2,
                }
            )
            models[strategy][path.stem] = payload

        pooled_y = np.concatenate(strategy_labels)
        pooled_pred = np.concatenate(strategy_predictions)
        summary_rows.append(
            {
                "strategy": strategy,
                "method": "Local-only pooled deployment",
                "clients": len(strategy_predictions),
                "epochs_per_client": args.epochs,
                "train_samples": train_total,
                "validation_samples": val_total,
                "test_samples": test_total,
                "threshold_policy": "per-client validation F1",
                "communication_client_updates": 0,
                "communication_sample_updates": 0,
                **metrics_from_predictions(pooled_y, pooled_pred),
            }
        )

    pd.DataFrame(client_rows).to_csv(args.reports / "local_only_client_results.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(args.reports / "local_only_summary_results.csv", index=False)
    pd.concat(history_rows, ignore_index=True).to_csv(
        args.reports / "local_only_training_history.csv", index=False
    )
    write_json(args.models / "local_only_models.json", models)
    print("Local-only baseline complete.")
    print(pd.DataFrame(summary_rows).to_string(index=False))


if __name__ == "__main__":
    main()
