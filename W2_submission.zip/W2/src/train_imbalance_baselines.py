from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from baseline_common import (
    FEATURES,
    TARGET,
    metrics,
    model_payload,
    oversample_binary,
    predict_proba,
    stratified_split,
    train_logistic,
    tune_threshold,
    validate_dataset,
    write_json,
)


METHODS = [
    ("unweighted_bce", "Unweighted BCE", "unweighted"),
    ("class_weighted_bce", "Class-weighted BCE", "class_weighted"),
    ("random_oversampling", "Random oversampling", "unweighted"),
    ("focal_loss", "Focal loss", "focal"),
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare centralized imbalance-learning baselines.")
    parser.add_argument("--data", type=Path, default=Path("data/processed/ai4i_clean_standardized.csv"))
    parser.add_argument("--reports", type=Path, default=Path("reports"))
    parser.add_argument("--models", type=Path, default=Path("models"))
    parser.add_argument("--epochs", type=int, default=500)
    parser.add_argument("--lr", type=float, default=0.08)
    parser.add_argument("--l2", type=float, default=0.001)
    parser.add_argument("--focal-alpha", type=float, default=0.75)
    parser.add_argument("--focal-gamma", type=float, default=2.0)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    args.reports.mkdir(parents=True, exist_ok=True)
    args.models.mkdir(parents=True, exist_ok=True)
    full = pd.read_csv(args.data)
    validate_dataset(full)
    train_idx, val_idx, test_idx = stratified_split(
        full[TARGET].to_numpy(dtype=int), 0.6, 0.2, args.seed
    )
    x = full[FEATURES].to_numpy(dtype=float)
    y = full[TARGET].to_numpy(dtype=int)
    x_val, y_val = x[val_idx], y[val_idx]
    x_test, y_test = x[test_idx], y[test_idx]

    result_rows: list[dict[str, object]] = []
    history_rows: list[pd.DataFrame] = []
    threshold_tables: list[pd.DataFrame] = []
    models: dict[str, object] = {}

    for key, label, loss_mode in METHODS:
        x_train, y_train = x[train_idx], y[train_idx]
        if key == "random_oversampling":
            x_train, y_train = oversample_binary(x_train, y_train, args.seed)

        weights, history = train_logistic(
            x_train,
            y_train,
            lr=args.lr,
            epochs=args.epochs,
            l2=args.l2,
            loss_mode=loss_mode,
            focal_alpha=args.focal_alpha,
            focal_gamma=args.focal_gamma,
        )
        history.insert(0, "method", key)
        history_rows.append(history)

        val_prob = predict_proba(x_val, weights)
        threshold, threshold_table = tune_threshold(y_val, val_prob)
        threshold_table.insert(0, "method", key)
        threshold_tables.append(threshold_table)
        final_metrics = metrics(y_test, predict_proba(x_test, weights), threshold)
        result_rows.append(
            {
                "strategy": "centralized",
                "method": label,
                "method_key": key,
                "epochs": args.epochs,
                "original_train_samples": len(train_idx),
                "effective_train_samples": len(y_train),
                "effective_positive_samples": int(y_train.sum()),
                "focal_alpha": args.focal_alpha if key == "focal_loss" else "",
                "focal_gamma": args.focal_gamma if key == "focal_loss" else "",
                **final_metrics,
            }
        )
        payload = model_payload(weights)
        payload.update(
            {
                "method": key,
                "threshold": threshold,
                "epochs": args.epochs,
                "learning_rate": args.lr,
                "l2": args.l2,
                "focal_alpha": args.focal_alpha if key == "focal_loss" else None,
                "focal_gamma": args.focal_gamma if key == "focal_loss" else None,
                "original_train_samples": len(train_idx),
                "effective_train_samples": len(y_train),
            }
        )
        models[key] = payload

    pd.DataFrame(result_rows).to_csv(args.reports / "imbalance_baseline_results.csv", index=False)
    pd.concat(history_rows, ignore_index=True).to_csv(
        args.reports / "imbalance_training_history.csv", index=False
    )
    pd.concat(threshold_tables, ignore_index=True).to_csv(
        args.reports / "imbalance_threshold_tuning.csv", index=False
    )
    write_json(args.models / "imbalance_models.json", models)
    print("Imbalance-learning baselines complete.")
    print(pd.DataFrame(result_rows).to_string(index=False))


if __name__ == "__main__":
    main()
