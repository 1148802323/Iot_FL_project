from __future__ import annotations

import subprocess
import sys
from pathlib import Path


SCRIPTS = [
    "train_local_only_baseline.py",
    "train_random_partial_fedavg.py",
    "train_fedprox_baseline.py",
    "train_imbalance_baselines.py",
    "build_comparison_report.py",
    "audit_fairness.py",
]


def main() -> None:
    src = Path(__file__).resolve().parent
    for script in SCRIPTS:
        print(f"\n=== Running {script} ===", flush=True)
        subprocess.run([sys.executable, str(src / script)], check=True)
    print("\nAll W2 baselines completed successfully.")


if __name__ == "__main__":
    main()
