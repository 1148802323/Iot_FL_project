from __future__ import annotations

import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    "data_preparation.py",
    "eda_cleaned.py",
    "build_model_dataset.py",
    "partition_factories.py",
    "train_centralized_baseline.py",
    "train_federated_baselines.py",
]


def main() -> None:
    for step_number, script_name in enumerate(STEPS, start=1):
        script_path = PROJECT_ROOT / "src" / script_name
        print(f"\n[{step_number}/{len(STEPS)}] Running {script_name}", flush=True)
        subprocess.run(
            [sys.executable, str(script_path)],
            cwd=PROJECT_ROOT,
            check=True,
        )

    print("\nWeek 1 pipeline completed successfully.")


if __name__ == "__main__":
    main()
