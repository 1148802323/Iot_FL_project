# 第一周进度说明

## 本周工作

本周完成了 AI4I 2020 预测性维护数据集的检查、清洗、探索性分析、工厂数据模拟和基础模型实验。

数据检查发现两类标签矛盾：

- 18 条记录的 `Machine failure` 为 0，但存在具体故障类型；
- 9 条记录的 `Machine failure` 为 1，但没有任何具体故障类型。

这 27 条记录已从清洗数据中删除。原始数据保留不变，清洗后共有 9,973 条记录。24 条同时包含多种故障模式的记录继续保留。在每一种实验划分内，每条记录只分配给一个工厂。

## 数据处理

模型使用以下输入：

- 产品类型 `Type`，转换为三个独热编码字段；
- 空气温度；
- 过程温度；
- 转速；
- 扭矩；
- 刀具磨损时间。

`UDI` 和 `Product ID` 仅用于标识，不作为模型输入。`Machine failure` 是主预测标签，具体故障类型及其派生字段仅作为辅助标签，未进入特征表。

数据按 80%/20% 划分为训练数据和全局测试数据：

- 工厂训练数据：7,978 条；
- 全局测试数据：1,995 条；
- 全局测试集故障率：3.31%。

训练数据模拟为 5 个工厂，并生成三种分布：

- IID；
- Moderate Non-IID，Dirichlet α=5.0；
- High Non-IID，Dirichlet α=0.5。

## 基线结果

集中式逻辑回归在全局测试集上的结果如下：

| Accuracy | Precision | Recall | F1 | PR-AUC |
|---:|---:|---:|---:|---:|
| 0.9629 | 0.4545 | 0.6061 | 0.5195 | 0.5372 |

Local-only、FedAvg 和 FedProx 的 F1 结果如下：

| 数据分布 | Local-only 平均值 | FedAvg | FedProx |
|---|---:|---:|---:|
| IID | 0.5278 | 0.5469 | 0.5512 |
| Moderate Non-IID | 0.4900 | 0.5512 | 0.5512 |
| High Non-IID | 0.3381 | 0.5512 | 0.5397 |

High Non-IID 条件下，Local-only 的结果下降较明显。FedAvg 和 FedProx 在当前全客户端参与、逻辑回归模型的设置下结果接近。

## 当前范围

本周实验使用逻辑回归验证数据流程和联邦训练流程。当前尚未实现客户端选择、故障感知聚合和动态权重，也未进行深度模型实验。后续实验将以现有集中式、Local-only、FedAvg 和 FedProx 结果作为对照。

## 复现方式

在 `code/week1` 目录运行：

```bash
uv sync
uv run python scripts/run_week1_pipeline.py
```

主要结果位于：

- `outputs/eda_cleaned/`
- `outputs/centralized_baseline/`
- `outputs/federated_baselines/`
