# Week 1 — AI4I 数据准备与联邦学习基线

本目录包含第一周的数据检查、清洗、EDA、Non-IID 工厂划分和基线实验。

本周进度见 [WEEK1_PROGRESS.md](WEEK1_PROGRESS.md)。

## 目录

```text
data/
  raw/          官方原始数据
  processed/    删除矛盾记录后的数据
  model/        分离后的特征表、标签表和 schema
  federated/    IID、Moderate Non-IID、High Non-IID 工厂数据
src/
  data_preparation.py
  eda_cleaned.py
  build_model_dataset.py
  partition_factories.py
  train_centralized_baseline.py
  train_federated_baselines.py
outputs/        数据检查、图表、指标和模型文件
scripts/
  run_week1_pipeline.py
```

## 环境

```bash
uv sync
```

## 一键运行

```bash
uv run python scripts/run_week1_pipeline.py
```

也可以按顺序单独运行：

```bash
uv run python src/data_preparation.py
uv run python src/eda_cleaned.py
uv run python src/build_model_dataset.py
uv run python src/partition_factories.py
uv run python src/train_centralized_baseline.py
uv run python src/train_federated_baselines.py
```

## 数据来源

UCI AI4I 2020 Predictive Maintenance Dataset：
<https://archive.ics.uci.edu/dataset/601/ai4i>

原始 CSV SHA-256：

```text
dc6630cd9b1f0f853922fad78a1b6436570d3f1ec863f1dd5c4340ac56bc8a8e
```
