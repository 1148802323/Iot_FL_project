from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = PROJECT_ROOT / "data" / "processed" / "ai4i_clean.csv"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "data" / "model"
ID_COLUMN = "UDI"
NUMERIC_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]
TYPE_FEATURES = ["Type_H", "Type_L", "Type_M"]
FEATURE_COLUMNS = [*TYPE_FEATURES, *NUMERIC_FEATURES]
TARGET_COLUMN = "Machine failure"
AUXILIARY_LABELS = [
    "TWF",
    "HDF",
    "PWF",
    "OSF",
    "RNF",
    "failure_mode_count",
    "failure_modes",
    "is_multi_failure",
]


def load_cleaned_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Cleaned dataset not found: {path}\n"
            "Run `uv run python src/data_preparation.py` first."
        )
    return pd.read_csv(path)


def build_feature_table(data: pd.DataFrame) -> pd.DataFrame:
    type_features = pd.get_dummies(
        data["Type"], prefix="Type", dtype="int8"
    ).reindex(columns=TYPE_FEATURES, fill_value=0)
    features = pd.concat(
        [
            data[[ID_COLUMN]].rename(columns={ID_COLUMN: "sample_id"}),
            type_features,
            data[NUMERIC_FEATURES],
        ],
        axis=1,
    )
    return features


def build_label_table(data: pd.DataFrame) -> pd.DataFrame:
    return pd.concat(
        [
            data[[ID_COLUMN]].rename(columns={ID_COLUMN: "sample_id"}),
            data[[TARGET_COLUMN, *AUXILIARY_LABELS]],
        ],
        axis=1,
    )


def validate_tables(
    data: pd.DataFrame,
    features: pd.DataFrame,
    labels: pd.DataFrame,
) -> None:
    if len(features) != len(data) or len(labels) != len(data):
        raise ValueError("Row count changed while building model tables")
    if features["sample_id"].duplicated().any():
        raise ValueError("Feature table has duplicate sample IDs")
    if not features["sample_id"].equals(labels["sample_id"]):
        raise ValueError("Feature and label tables are not aligned")
    if features.isna().any().any() or labels.isna().any().any():
        raise ValueError("Model tables contain missing values")
    if list(features.columns) != ["sample_id", *FEATURE_COLUMNS]:
        raise ValueError("Unexpected feature-table schema")
    if set(TYPE_FEATURES) - set(features.columns):
        raise ValueError("A product-type one-hot column is missing")
    if not features[TYPE_FEATURES].sum(axis=1).eq(1).all():
        raise ValueError("Product-type one-hot encoding is invalid")
    forbidden = {TARGET_COLUMN, *AUXILIARY_LABELS}
    leaked = forbidden.intersection(features.columns)
    if leaked:
        raise ValueError(f"Label leakage in feature table: {sorted(leaked)}")


def save_outputs(
    features: pd.DataFrame,
    labels: pd.DataFrame,
    output_dir: Path,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    features.to_csv(output_dir / "ai4i_features.csv", index=False)
    labels.to_csv(output_dir / "ai4i_labels.csv", index=False)

    schema = {
        "sample_id": "sample_id",
        "feature_columns": FEATURE_COLUMNS,
        "primary_target": TARGET_COLUMN,
        "auxiliary_labels": AUXILIARY_LABELS,
        "standardized": False,
        "standardization_note": (
            "Fit scaling parameters on each training split/client only; "
            "never on the full dataset."
        ),
    }
    (output_dir / "schema.json").write_text(
        json.dumps(schema, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build leakage-safe AI4I feature and label tables."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = load_cleaned_data(args.input.resolve())
    features = build_feature_table(data)
    labels = build_label_table(data)
    validate_tables(data, features, labels)
    save_outputs(features, labels, args.output_dir.resolve())

    print(f"Rows: {len(features):,}")
    print(f"Model features: {len(FEATURE_COLUMNS)}")
    print("Feature columns: " + ", ".join(FEATURE_COLUMNS))
    print(f"Primary target: {TARGET_COLUMN}")
    print("Label leakage in feature table: 0 columns")
    print(f"Outputs written to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
