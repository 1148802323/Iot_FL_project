from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = PROJECT_ROOT / "data" / "raw" / "ai4i2020.csv"
DEFAULT_AUDIT_DIR = PROJECT_ROOT / "outputs" / "data_checks"
DEFAULT_CLEAN_OUTPUT = PROJECT_ROOT / "data" / "processed" / "ai4i_clean.csv"
FAILURE_MODES = ["TWF", "HDF", "PWF", "OSF", "RNF"]

EXPECTED_COLUMNS = [
    "UDI",
    "Product ID",
    "Type",
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
    "Machine failure",
    "TWF",
    "HDF",
    "PWF",
    "OSF",
    "RNF",
]


def load_raw_data(path: Path) -> pd.DataFrame:
    """Load the original AI4I CSV without changing its values."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    data = pd.read_csv(path, encoding="utf-8-sig")

    missing_columns = sorted(set(EXPECTED_COLUMNS) - set(data.columns))
    extra_columns = sorted(set(data.columns) - set(EXPECTED_COLUMNS))
    if missing_columns or extra_columns:
        raise ValueError(
            "Unexpected dataset columns. "
            f"Missing: {missing_columns or 'none'}; "
            f"extra: {extra_columns or 'none'}"
        )

    return data


def print_basic_profile(data: pd.DataFrame, source: Path) -> None:
    """Print the checks required before adding any cleaning logic."""
    print(f"Source: {source}")
    print(f"Shape: {data.shape[0]:,} rows x {data.shape[1]} columns")
    print(f"Duplicate rows: {data.duplicated().sum():,}")
    print(f"Missing cells: {data.isna().sum().sum():,}")
    print(f"Unique UDI: {data['UDI'].nunique():,}")
    print(f"Unique Product ID: {data['Product ID'].nunique():,}")

    print("\nProduct type counts:")
    print(data["Type"].value_counts().sort_index().to_string())

    print("\nMachine failure counts:")
    print(data["Machine failure"].value_counts().sort_index().to_string())

    print("\nFailure-mode positive counts:")
    print(data[["TWF", "HDF", "PWF", "OSF", "RNF"]].sum().to_string())


def validate_basic_quality(data: pd.DataFrame) -> None:
    """Fail immediately if the raw file does not meet its basic contract."""
    if len(data) != 10_000:
        raise ValueError(f"Expected 10,000 rows, found {len(data):,}")
    if data.duplicated().any():
        raise ValueError("Raw data contains duplicate rows")
    if data.isna().any().any():
        raise ValueError("Raw data contains missing values")
    if not data["UDI"].is_unique:
        raise ValueError("UDI is not unique")
    if not data["Product ID"].is_unique:
        raise ValueError("Product ID is not unique")


def audit_failure_labels(
    data: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Find label conflicts and multi-failure rows without changing the data."""
    active_mode_count = data[FAILURE_MODES].sum(axis=1)

    failure_zero_with_mode = data[
        (data["Machine failure"] == 0) & (active_mode_count > 0)
    ].copy()
    failure_one_without_mode = data[
        (data["Machine failure"] == 1) & (active_mode_count == 0)
    ].copy()
    multiple_failure_modes = data[active_mode_count > 1].copy()

    print("\nFailure-label audit:")
    print(
        "Machine failure = 0 but at least one failure mode = 1: "
        f"{len(failure_zero_with_mode):,}"
    )
    print(
        "Machine failure = 1 but all failure modes = 0: "
        f"{len(failure_one_without_mode):,}"
    )
    print(f"Rows with multiple active failure modes: {len(multiple_failure_modes):,}")

    if not failure_zero_with_mode.empty:
        print("\nActive modes in the first conflict group:")
        print(
            failure_zero_with_mode[FAILURE_MODES]
            .sum()
            .loc[lambda counts: counts > 0]
            .to_string()
        )
        print(
            "UDI values: "
            + ", ".join(failure_zero_with_mode["UDI"].astype(str).tolist())
        )

    if not failure_one_without_mode.empty:
        print(
            "\nUDI values with Machine failure = 1 and no active mode: "
            + ", ".join(failure_one_without_mode["UDI"].astype(str).tolist())
        )

    return (
        failure_zero_with_mode,
        failure_one_without_mode,
        multiple_failure_modes,
    )


def export_failure_audit(
    audit_frames: tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame],
    output_dir: Path,
) -> None:
    """Save the raw rows that need a later cleaning decision."""
    output_dir.mkdir(parents=True, exist_ok=True)
    names = [
        "machine_failure_0_with_active_mode.csv",
        "machine_failure_1_without_active_mode.csv",
        "multiple_failure_modes.csv",
    ]

    for name, frame in zip(names, audit_frames, strict=True):
        frame.to_csv(output_dir / name, index=False)

    print(f"\nAudit rows written to: {output_dir}")


def create_clean_copy(data: pd.DataFrame) -> pd.DataFrame:
    """Remove contradictory rows and preserve all remaining official fields."""
    active_mode_count = data[FAILURE_MODES].sum(axis=1)
    contradictory = (
        (data["Machine failure"].eq(0) & active_mode_count.gt(0))
        | (data["Machine failure"].eq(1) & active_mode_count.eq(0))
    )
    clean = data.loc[~contradictory].copy()

    clean["failure_mode_count"] = clean[FAILURE_MODES].sum(axis=1)
    clean["failure_modes"] = clean[FAILURE_MODES].apply(
        lambda row: "|".join(row.index[row.eq(1)]) or "NONE",
        axis=1,
    )
    clean["is_multi_failure"] = clean["failure_mode_count"].gt(1).astype("int8")
    return clean


def validate_clean_copy(raw: pd.DataFrame, clean: pd.DataFrame) -> None:
    """Verify that only contradictory rows were removed."""
    active_mode_count = raw[FAILURE_MODES].sum(axis=1)
    contradictory = (
        (raw["Machine failure"].eq(0) & active_mode_count.gt(0))
        | (raw["Machine failure"].eq(1) & active_mode_count.eq(0))
    )
    expected = raw.loc[~contradictory]

    if not expected.equals(clean[raw.columns]):
        raise ValueError("An official source column was modified")

    clean_mode_active = clean[FAILURE_MODES].any(axis=1).astype("int64")
    inconsistent = clean_mode_active.ne(clean["Machine failure"])
    if inconsistent.any():
        raise ValueError(
            f"{int(inconsistent.sum())} label conflicts remain after cleaning"
        )

    print("\nClean-copy validation:")
    print(f"Original rows: {len(raw):,}")
    print(f"Contradictory rows removed: {int(contradictory.sum()):,}")
    print(f"Clean rows: {len(clean):,}")
    print(f"Remaining label conflicts: {int(inconsistent.sum()):,}")
    print(f"Multi-failure rows retained: {int(clean['is_multi_failure'].sum()):,}")


def export_clean_data(clean: pd.DataFrame, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    clean.to_csv(output_path, index=False)
    print(f"Cleaned copy written to: {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare the AI4I dataset step by step.")
    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT,
        help="Path to the original ai4i2020.csv file.",
    )
    parser.add_argument(
        "--audit-dir",
        type=Path,
        default=DEFAULT_AUDIT_DIR,
        help="Directory for exported label-audit rows.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_CLEAN_OUTPUT,
        help="Path for the cleaned CSV copy.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    source = args.input.resolve()
    data = load_raw_data(source)
    print_basic_profile(data, source)
    validate_basic_quality(data)
    print("\nBasic quality checks passed.")
    audit_frames = audit_failure_labels(data)
    export_failure_audit(audit_frames, args.audit_dir.resolve())
    clean = create_clean_copy(data)
    validate_clean_copy(data, clean)
    export_clean_data(clean, args.output.resolve())


if __name__ == "__main__":
    main()
