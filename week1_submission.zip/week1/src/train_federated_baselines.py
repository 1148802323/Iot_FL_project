from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FEDERATED_DIR = PROJECT_ROOT / "data" / "federated"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "outputs" / "federated_baselines"
STRATEGIES = ["iid", "moderate_non_iid", "high_non_iid"]
TARGET = "Machine failure"
NUMERIC_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]


def sigmoid(values: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(values, -30, 30)))


def add_intercept(features: np.ndarray) -> np.ndarray:
    return np.column_stack([features, np.ones(len(features))])


def train_logistic(
    features: np.ndarray,
    labels: np.ndarray,
    initial_weights: np.ndarray,
    epochs: int,
    learning_rate: float,
    l2: float,
    proximal_mu: float = 0.0,
    proximal_center: np.ndarray | None = None,
) -> np.ndarray:
    weights = initial_weights.copy()
    for _ in range(epochs):
        probabilities = sigmoid(features @ weights)
        gradient = features.T @ (probabilities - labels) / len(labels)

        regularization = weights.copy()
        regularization[-1] = 0.0
        gradient += l2 * regularization

        if proximal_mu > 0:
            if proximal_center is None:
                raise ValueError("FedProx requires a proximal center")
            gradient += proximal_mu * (weights - proximal_center)

        weights -= learning_rate * gradient
    return weights


def classification_metrics(
    labels: np.ndarray,
    probabilities: np.ndarray,
    threshold: float,
) -> dict[str, float | int]:
    predictions = (probabilities >= threshold).astype("int8")
    tn, fp, fn, tp = confusion_matrix(labels, predictions, labels=[0, 1]).ravel()
    return {
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(labels, predictions)),
        "precision": float(
            precision_score(labels, predictions, zero_division=0)
        ),
        "recall": float(recall_score(labels, predictions, zero_division=0)),
        "f1": float(f1_score(labels, predictions, zero_division=0)),
        "pr_auc_average_precision": float(
            average_precision_score(labels, probabilities)
        ),
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def find_best_threshold(
    labels: np.ndarray,
    probabilities: np.ndarray,
) -> tuple[float, pd.DataFrame]:
    rows = [
        classification_metrics(labels, probabilities, threshold)
        for threshold in np.linspace(0.05, 0.95, 91)
    ]
    table = pd.DataFrame(rows)
    best = table.sort_values(
        ["f1", "recall", "precision"],
        ascending=False,
    ).iloc[0]
    return float(best["threshold"]), table


def load_global_sets(
    federated_dir: Path,
    validation_fraction: float,
    seed: int,
) -> tuple[set[int], set[int], pd.DataFrame, np.ndarray]:
    split = pd.read_csv(federated_dir / "global_split_assignment.csv")
    train_ids = split.loc[split["split"].eq("train"), "sample_id"]

    all_labels = []
    for path in sorted((federated_dir / "iid").glob("factory_*_labels.csv")):
        all_labels.append(pd.read_csv(path)[["sample_id", TARGET]])
    train_labels = pd.concat(all_labels, ignore_index=True).sort_values("sample_id")

    development_ids, validation_ids = train_test_split(
        train_labels["sample_id"],
        test_size=validation_fraction,
        stratify=train_labels[TARGET],
        random_state=seed,
    )

    test_features = pd.read_csv(federated_dir / "global_test_features.csv")
    test_labels = pd.read_csv(federated_dir / "global_test_labels.csv")
    if not test_features["sample_id"].equals(test_labels["sample_id"]):
        raise ValueError("Global-test feature and label tables are not aligned")
    if set(train_ids).intersection(test_features["sample_id"]):
        raise ValueError("Training and global-test sets overlap")

    global_test = test_features.merge(
        test_labels[["sample_id", TARGET]],
        on="sample_id",
        validate="one_to_one",
    )
    feature_columns = [
        column for column in test_features.columns if column != "sample_id"
    ]
    return (
        set(development_ids),
        set(validation_ids),
        global_test,
        np.array(feature_columns),
    )


def load_clients(
    strategy_dir: Path,
    included_ids: set[int],
    feature_columns: list[str],
) -> list[dict[str, object]]:
    clients = []
    for feature_path in sorted(strategy_dir.glob("factory_*_features.csv")):
        factory = feature_path.stem.removesuffix("_features")
        label_path = strategy_dir / f"{factory}_labels.csv"
        features = pd.read_csv(feature_path)
        labels = pd.read_csv(label_path)
        data = features.merge(
            labels[["sample_id", TARGET]],
            on="sample_id",
            validate="one_to_one",
        )
        data = data[data["sample_id"].isin(included_ids)].copy()
        if data.empty:
            raise ValueError(f"{factory} has no included rows")
        clients.append(
            {
                "factory": factory,
                "sample_id": data["sample_id"].to_numpy(),
                "x_raw": data[feature_columns].to_numpy(dtype="float64"),
                "y": data[TARGET].to_numpy(dtype="float64"),
            }
        )
    if not clients:
        raise ValueError(f"No factories found in {strategy_dir}")
    return clients


def load_validation_set(
    strategy_dir: Path,
    validation_ids: set[int],
    feature_columns: list[str],
) -> tuple[np.ndarray, np.ndarray]:
    clients = load_clients(strategy_dir, validation_ids, feature_columns)
    features = np.concatenate([client["x_raw"] for client in clients])
    labels = np.concatenate([client["y"] for client in clients])
    return features, labels


def aggregate_standardizer(
    clients: list[dict[str, object]],
    numeric_indices: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    count = sum(len(client["x_raw"]) for client in clients)
    total = sum(
        np.asarray(client["x_raw"])[:, numeric_indices].sum(axis=0)
        for client in clients
    )
    total_squared = sum(
        np.square(np.asarray(client["x_raw"])[:, numeric_indices]).sum(axis=0)
        for client in clients
    )
    mean = total / count
    variance = np.maximum(total_squared / count - np.square(mean), 0.0)
    scale = np.sqrt(variance)
    scale[scale == 0] = 1.0
    return mean, scale


def transform_features(
    raw_features: np.ndarray,
    numeric_indices: np.ndarray,
    mean: np.ndarray,
    scale: np.ndarray,
) -> np.ndarray:
    transformed = raw_features.copy()
    transformed[:, numeric_indices] = (
        transformed[:, numeric_indices] - mean
    ) / scale
    return add_intercept(transformed)


def prepare_federated_features(
    clients: list[dict[str, object]],
    raw_validation: np.ndarray,
    raw_test: np.ndarray,
    numeric_indices: np.ndarray,
) -> tuple[list[dict[str, object]], np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mean, scale = aggregate_standardizer(clients, numeric_indices)
    prepared_clients = []
    for client in clients:
        prepared_clients.append(
            {
                **client,
                "x": transform_features(
                    np.asarray(client["x_raw"]),
                    numeric_indices,
                    mean,
                    scale,
                ),
            }
        )
    validation = transform_features(
        raw_validation,
        numeric_indices,
        mean,
        scale,
    )
    test = transform_features(raw_test, numeric_indices, mean, scale)
    return prepared_clients, validation, test, mean, scale


def train_federated(
    clients: list[dict[str, object]],
    evaluation_features: np.ndarray | None,
    evaluation_labels: np.ndarray | None,
    rounds: int,
    local_epochs: int,
    learning_rate: float,
    l2: float,
    proximal_mu: float,
) -> tuple[np.ndarray, pd.DataFrame]:
    dimension = np.asarray(clients[0]["x"]).shape[1]
    global_weights = np.zeros(dimension, dtype="float64")
    total_rows = sum(len(client["y"]) for client in clients)
    history_rows = []

    for round_number in range(1, rounds + 1):
        local_weights = []
        local_sizes = []
        for client in clients:
            updated = train_logistic(
                np.asarray(client["x"]),
                np.asarray(client["y"]),
                global_weights,
                local_epochs,
                learning_rate,
                l2,
                proximal_mu=proximal_mu,
                proximal_center=global_weights,
            )
            local_weights.append(updated)
            local_sizes.append(len(client["y"]))

        global_weights = sum(
            weight * (size / total_rows)
            for weight, size in zip(local_weights, local_sizes, strict=True)
        )
        if evaluation_features is not None and evaluation_labels is not None:
            evaluation_probability = sigmoid(evaluation_features @ global_weights)
            metrics = classification_metrics(
                evaluation_labels,
                evaluation_probability,
                threshold=0.5,
            )
            history_rows.append({"round": round_number, **metrics})

    return global_weights, pd.DataFrame(history_rows)


def evaluate_federated_method(
    strategy: str,
    method: str,
    development_clients: list[dict[str, object]],
    full_clients: list[dict[str, object]],
    raw_validation: np.ndarray,
    validation_labels: np.ndarray,
    raw_test: np.ndarray,
    test_labels: np.ndarray,
    numeric_indices: np.ndarray,
    rounds: int,
    local_epochs: int,
    learning_rate: float,
    l2: float,
    proximal_mu: float,
) -> tuple[dict[str, object], pd.DataFrame, dict[str, np.ndarray]]:
    dev_clients, dev_validation, _, _, _ = prepare_federated_features(
        development_clients,
        raw_validation,
        raw_test,
        numeric_indices,
    )
    dev_weights, history = train_federated(
        dev_clients,
        dev_validation,
        validation_labels,
        rounds,
        local_epochs,
        learning_rate,
        l2,
        proximal_mu,
    )
    validation_probability = sigmoid(dev_validation @ dev_weights)
    threshold, _ = find_best_threshold(validation_labels, validation_probability)

    final_clients, _, final_test, mean, scale = prepare_federated_features(
        full_clients,
        raw_validation,
        raw_test,
        numeric_indices,
    )
    final_weights, _ = train_federated(
        final_clients,
        None,
        None,
        rounds,
        local_epochs,
        learning_rate,
        l2,
        proximal_mu,
    )
    test_probability = sigmoid(final_test @ final_weights)
    metrics = classification_metrics(test_labels, test_probability, threshold)
    result: dict[str, object] = {
        "strategy": strategy,
        "method": method,
        "factory": "global",
        "train_rows": sum(len(client["y"]) for client in full_clients),
        **metrics,
    }
    artifacts = {
        "weights": final_weights,
        "numeric_mean": mean,
        "numeric_scale": scale,
    }
    return result, history, artifacts


def evaluate_local_models(
    strategy: str,
    development_clients: list[dict[str, object]],
    full_clients: list[dict[str, object]],
    raw_validation: np.ndarray,
    validation_labels: np.ndarray,
    raw_test: np.ndarray,
    test_labels: np.ndarray,
    numeric_indices: np.ndarray,
    total_epochs: int,
    learning_rate: float,
    l2: float,
) -> list[dict[str, object]]:
    results = []
    full_by_factory = {
        str(client["factory"]): client for client in full_clients
    }
    for dev_client in development_clients:
        factory = str(dev_client["factory"])
        full_client = full_by_factory[factory]

        dev_mean, dev_scale = aggregate_standardizer(
            [dev_client],
            numeric_indices,
        )
        dev_x = transform_features(
            np.asarray(dev_client["x_raw"]),
            numeric_indices,
            dev_mean,
            dev_scale,
        )
        dev_validation = transform_features(
            raw_validation,
            numeric_indices,
            dev_mean,
            dev_scale,
        )
        dev_weights = train_logistic(
            dev_x,
            np.asarray(dev_client["y"]),
            np.zeros(dev_x.shape[1]),
            total_epochs,
            learning_rate,
            l2,
        )
        validation_probability = sigmoid(dev_validation @ dev_weights)
        threshold, _ = find_best_threshold(
            validation_labels,
            validation_probability,
        )

        full_mean, full_scale = aggregate_standardizer(
            [full_client],
            numeric_indices,
        )
        full_x = transform_features(
            np.asarray(full_client["x_raw"]),
            numeric_indices,
            full_mean,
            full_scale,
        )
        final_test = transform_features(
            raw_test,
            numeric_indices,
            full_mean,
            full_scale,
        )
        final_weights = train_logistic(
            full_x,
            np.asarray(full_client["y"]),
            np.zeros(full_x.shape[1]),
            total_epochs,
            learning_rate,
            l2,
        )
        test_probability = sigmoid(final_test @ final_weights)
        metrics = classification_metrics(test_labels, test_probability, threshold)
        results.append(
            {
                "strategy": strategy,
                "method": "local_only",
                "factory": factory,
                "train_rows": len(full_client["y"]),
                **metrics,
            }
        )
    return results


def build_comparison_summary(results: pd.DataFrame) -> pd.DataFrame:
    metric_columns = [
        "accuracy",
        "precision",
        "recall",
        "f1",
        "pr_auc_average_precision",
        "roc_auc",
    ]
    federated = results[results["method"].ne("local_only")].copy()
    local = (
        results[results["method"].eq("local_only")]
        .groupby("strategy", as_index=False)[metric_columns]
        .mean()
    )
    local.insert(1, "method", "local_only_mean")
    return pd.concat(
        [local, federated[["strategy", "method", *metric_columns]]],
        ignore_index=True,
    ).sort_values(["strategy", "method"])


def save_comparison_figure(summary: pd.DataFrame, output_path: Path) -> None:
    metrics = ["recall", "f1", "pr_auc_average_precision"]
    labels = {
        "local_only_mean": "Local mean",
        "fedavg": "FedAvg",
        "fedprox": "FedProx",
    }
    colors = {
        "local_only_mean": "#6B7280",
        "fedavg": "#2457A6",
        "fedprox": "#D97706",
    }
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.5), sharey=True)
    x = np.arange(len(STRATEGIES))
    width = 0.24

    for axis, metric in zip(axes, metrics, strict=True):
        for method_index, method in enumerate(labels):
            values = []
            for strategy in STRATEGIES:
                value = summary.loc[
                    summary["strategy"].eq(strategy)
                    & summary["method"].eq(method),
                    metric,
                ].iloc[0]
                values.append(value)
            axis.bar(
                x + (method_index - 1) * width,
                values,
                width,
                label=labels[method],
                color=colors[method],
            )
        axis.set_title(metric.replace("_", " ").title())
        axis.set_xticks(x)
        axis.set_xticklabels(["IID", "Moderate", "High"])
        axis.set_ylim(0, 1)
        axis.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("Score")
    axes[-1].legend(loc="upper right")
    figure.suptitle("Federated baseline performance on the global test set")
    figure.tight_layout()
    figure.savefig(output_path, dpi=160)
    plt.close(figure)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train Local-only, FedAvg, and FedProx baselines."
    )
    parser.add_argument(
        "--federated-dir",
        type=Path,
        default=DEFAULT_FEDERATED_DIR,
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--validation-fraction", type=float, default=0.20)
    parser.add_argument("--rounds", type=int, default=200)
    parser.add_argument("--local-epochs", type=int, default=10)
    parser.add_argument("--learning-rate", type=float, default=0.1)
    parser.add_argument("--l2", type=float, default=1e-4)
    parser.add_argument("--fedprox-mu", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    federated_dir = args.federated_dir.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    development_ids, validation_ids, global_test, feature_array = load_global_sets(
        federated_dir,
        args.validation_fraction,
        args.seed,
    )
    feature_columns = feature_array.tolist()
    numeric_indices = np.array(
        [feature_columns.index(column) for column in NUMERIC_FEATURES]
    )
    raw_test = global_test[feature_columns].to_numpy(dtype="float64")
    test_labels = global_test[TARGET].to_numpy(dtype="float64")

    all_results: list[dict[str, object]] = []
    histories = []
    for strategy in STRATEGIES:
        strategy_dir = federated_dir / strategy
        development_clients = load_clients(
            strategy_dir,
            development_ids,
            feature_columns,
        )
        full_clients = load_clients(
            strategy_dir,
            development_ids.union(validation_ids),
            feature_columns,
        )
        raw_validation, validation_labels = load_validation_set(
            strategy_dir,
            validation_ids,
            feature_columns,
        )

        all_results.extend(
            evaluate_local_models(
                strategy,
                development_clients,
                full_clients,
                raw_validation,
                validation_labels,
                raw_test,
                test_labels,
                numeric_indices,
                args.rounds * args.local_epochs,
                args.learning_rate,
                args.l2,
            )
        )

        for method, proximal_mu in [
            ("fedavg", 0.0),
            ("fedprox", args.fedprox_mu),
        ]:
            result, history, artifacts = evaluate_federated_method(
                strategy,
                method,
                development_clients,
                full_clients,
                raw_validation,
                validation_labels,
                raw_test,
                test_labels,
                numeric_indices,
                args.rounds,
                args.local_epochs,
                args.learning_rate,
                args.l2,
                proximal_mu,
            )
            all_results.append(result)
            history.insert(0, "method", method)
            history.insert(0, "strategy", strategy)
            histories.append(history)
            np.savez(
                output_dir / f"{strategy}_{method}_model.npz",
                **artifacts,
            )

    detailed_results = pd.DataFrame(all_results)
    comparison = build_comparison_summary(detailed_results)
    detailed_results.to_csv(output_dir / "detailed_results.csv", index=False)
    comparison.to_csv(output_dir / "comparison_summary.csv", index=False)
    pd.concat(histories, ignore_index=True).to_csv(
        output_dir / "round_history.csv",
        index=False,
    )
    save_comparison_figure(
        comparison,
        output_dir / "baseline_comparison.png",
    )

    config = {
        "rounds": args.rounds,
        "local_epochs": args.local_epochs,
        "learning_rate": args.learning_rate,
        "l2": args.l2,
        "fedprox_mu": args.fedprox_mu,
        "validation_fraction": args.validation_fraction,
        "threshold_selection": "maximum validation F1; recall and precision tie-break",
        "global_test_used_for_selection": False,
        "all_clients_participate_each_round": True,
    }
    (output_dir / "config.json").write_text(
        json.dumps(config, indent=2) + "\n",
        encoding="utf-8",
    )

    print("Global-test comparison:")
    print(
        comparison[
            [
                "strategy",
                "method",
                "precision",
                "recall",
                "f1",
                "pr_auc_average_precision",
            ]
        ].to_string(index=False, float_format=lambda value: f"{value:.4f}")
    )
    print(f"\nOutputs written to: {output_dir}")


if __name__ == "__main__":
    main()
