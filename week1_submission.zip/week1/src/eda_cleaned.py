from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = PROJECT_ROOT / "data" / "processed" / "ai4i_clean.csv"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "outputs" / "eda_cleaned"
FAILURE_MODES = ["TWF", "HDF", "PWF", "OSF", "RNF"]
NUMERIC_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]
MODEL_FEATURES = ["Type", *NUMERIC_FEATURES]


def load_cleaned_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Cleaned dataset not found: {path}\n"
            "Run `uv run python src/data_preparation.py` first."
        )
    return pd.read_csv(path)


def validate_cleaned_data(data: pd.DataFrame) -> None:
    required = {
        "UDI",
        "Product ID",
        "Type",
        "Machine failure",
        "failure_mode_count",
        "failure_modes",
        "is_multi_failure",
        *FAILURE_MODES,
        *NUMERIC_FEATURES,
    }
    missing = sorted(required - set(data.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if len(data) != 9_973:
        raise ValueError(f"Expected 9,973 cleaned rows, found {len(data):,}")
    if data.isna().any().any():
        raise ValueError("Cleaned data contains missing values")
    if data.duplicated().any():
        raise ValueError("Cleaned data contains duplicate rows")
    if not data["UDI"].is_unique:
        raise ValueError("UDI is not unique")

    mode_active = data[FAILURE_MODES].any(axis=1).astype("int64")
    conflicts = mode_active.ne(data["Machine failure"])
    if conflicts.any():
        raise ValueError(f"Found {int(conflicts.sum())} remaining label conflicts")


def build_summary_tables(data: pd.DataFrame) -> dict[str, pd.DataFrame]:
    numeric_summary = (
        data[NUMERIC_FEATURES]
        .describe(percentiles=[0.01, 0.25, 0.5, 0.75, 0.99])
        .T.rename(columns={"50%": "median"})
    )

    type_summary = (
        data.groupby("Type", observed=True)["Machine failure"]
        .agg(rows="size", failures="sum", failure_rate="mean")
        .reset_index()
    )
    type_summary["failure_rate_pct"] = type_summary["failure_rate"] * 100

    mode_summary = pd.DataFrame(
        {
            "failure_mode": FAILURE_MODES,
            "positive_rows": [int(data[column].sum()) for column in FAILURE_MODES],
        }
    )
    mode_summary["share_of_all_rows_pct"] = (
        mode_summary["positive_rows"] / len(data) * 100
    )

    label_summary = (
        data["Machine failure"]
        .value_counts()
        .sort_index()
        .rename_axis("machine_failure")
        .reset_index(name="rows")
    )
    label_summary["share_pct"] = label_summary["rows"] / len(data) * 100

    outlier_rows = []
    for column in NUMERIC_FEATURES:
        q1 = data[column].quantile(0.25)
        q3 = data[column].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        count = int(((data[column] < lower) | (data[column] > upper)).sum())
        outlier_rows.append(
            {
                "feature": column,
                "lower_bound": lower,
                "upper_bound": upper,
                "outlier_rows": count,
                "outlier_rate_pct": count / len(data) * 100,
            }
        )
    outlier_summary = pd.DataFrame(outlier_rows)

    numeric_correlations = data[NUMERIC_FEATURES].corr(method="spearman")

    target_association = (
        data[[*NUMERIC_FEATURES, "Machine failure"]]
        .corr(method="spearman")["Machine failure"]
        .drop("Machine failure")
        .rename("spearman_with_machine_failure")
        .sort_values(key=abs, ascending=False)
        .rename_axis("feature")
        .reset_index()
    )

    feature_decisions = pd.DataFrame(
        [
            {
                "column": "UDI",
                "role": "identifier",
                "use_as_model_feature": False,
                "reason": "Row identifier/order; no physical meaning.",
            },
            {
                "column": "Product ID",
                "role": "identifier",
                "use_as_model_feature": False,
                "reason": "Unique identifier; first character duplicates Type.",
            },
            *[
                {
                    "column": column,
                    "role": "input feature",
                    "use_as_model_feature": True,
                    "reason": "Available machine/product measurement.",
                }
                for column in MODEL_FEATURES
            ],
            {
                "column": "Machine failure",
                "role": "primary target",
                "use_as_model_feature": False,
                "reason": "Prediction target.",
            },
            *[
                {
                    "column": column,
                    "role": "failure-mode label",
                    "use_as_model_feature": False,
                    "reason": "Directly reveals the primary target; label leakage.",
                }
                for column in FAILURE_MODES
            ],
            *[
                {
                    "column": column,
                    "role": "derived label",
                    "use_as_model_feature": False,
                    "reason": "Derived from failure-mode labels; label leakage.",
                }
                for column in [
                    "failure_mode_count",
                    "failure_modes",
                    "is_multi_failure",
                ]
            ],
        ]
    )

    return {
        "numeric_summary": numeric_summary,
        "type_failure_summary": type_summary,
        "failure_mode_summary": mode_summary,
        "label_summary": label_summary,
        "outlier_summary": outlier_summary,
        "numeric_correlations": numeric_correlations,
        "target_association": target_association,
        "model_feature_decisions": feature_decisions,
    }


def save_summary_tables(
    tables: dict[str, pd.DataFrame], output_dir: Path
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        keep_index = name in {"numeric_summary", "numeric_correlations"}
        table.to_csv(output_dir / f"{name}.csv", index=keep_index)


def save_figures(
    data: pd.DataFrame,
    tables: dict[str, pd.DataFrame],
    output_dir: Path,
) -> None:
    figure_dir = output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    blue = "#2457A6"
    orange = "#D97706"
    ink = "#182230"

    figure, axes = plt.subplots(2, 3, figsize=(15, 8))
    for axis, column in zip(axes.flat, NUMERIC_FEATURES, strict=False):
        sns.histplot(data=data, x=column, bins=35, color=blue, ax=axis)
        axis.set_title(column, color=ink)
        axis.set_ylabel("Rows")
    axes.flat[-1].axis("off")
    figure.suptitle(
        "Numeric feature distributions — cleaned AI4I data (n=9,973)",
        fontsize=16,
        color=ink,
    )
    figure.tight_layout()
    figure.savefig(figure_dir / "numeric_feature_distributions.png", dpi=160)
    plt.close(figure)

    type_summary = tables["type_failure_summary"]
    figure, axis = plt.subplots(figsize=(7, 4.5))
    sns.barplot(
        data=type_summary,
        x="Type",
        y="failure_rate_pct",
        color=blue,
        ax=axis,
    )
    axis.set_title("Machine-failure rate by product type", color=ink)
    axis.set_xlabel("Product type")
    axis.set_ylabel("Failure rate (%)")
    axis.set_ylim(0, type_summary["failure_rate_pct"].max() * 1.2)
    for container in axis.containers:
        axis.bar_label(container, fmt="%.2f%%", padding=3)
    figure.tight_layout()
    figure.savefig(figure_dir / "failure_rate_by_type.png", dpi=160)
    plt.close(figure)

    mode_summary = tables["failure_mode_summary"].sort_values(
        "positive_rows", ascending=True
    )
    figure, axis = plt.subplots(figsize=(7, 4.5))
    sns.barplot(
        data=mode_summary,
        x="positive_rows",
        y="failure_mode",
        color=orange,
        ax=axis,
    )
    axis.set_title("Positive rows by failure mode", color=ink)
    axis.set_xlabel("Positive rows")
    axis.set_ylabel("Failure mode")
    for container in axis.containers:
        axis.bar_label(container, padding=3)
    figure.tight_layout()
    figure.savefig(figure_dir / "failure_mode_counts.png", dpi=160)
    plt.close(figure)

    correlation = tables["numeric_correlations"]
    figure, axis = plt.subplots(figsize=(8, 6))
    sns.heatmap(
        correlation,
        vmin=-1,
        vmax=1,
        center=0,
        cmap=sns.diverging_palette(35, 240, as_cmap=True),
        annot=True,
        fmt=".2f",
        square=True,
        ax=axis,
    )
    axis.set_title("Spearman correlations among numeric model features", color=ink)
    figure.tight_layout()
    figure.savefig(figure_dir / "numeric_feature_correlations.png", dpi=160)
    plt.close(figure)

    figure, axes = plt.subplots(2, 3, figsize=(15, 8))
    for axis, column in zip(axes.flat, NUMERIC_FEATURES, strict=False):
        sns.boxplot(
            data=data,
            x="Machine failure",
            y=column,
            color=blue,
            showfliers=False,
            ax=axis,
        )
        axis.set_title(column, color=ink)
        axis.set_xlabel("Machine failure")
    axes.flat[-1].axis("off")
    figure.suptitle(
        "Numeric features by machine-failure label (outlier markers hidden)",
        fontsize=16,
        color=ink,
    )
    figure.tight_layout()
    figure.savefig(figure_dir / "numeric_features_by_target.png", dpi=160)
    plt.close(figure)


def print_key_results(
    data: pd.DataFrame, tables: dict[str, pd.DataFrame], output_dir: Path
) -> None:
    failures = int(data["Machine failure"].sum())
    print(f"Rows: {len(data):,}")
    print(f"Columns: {data.shape[1]}")
    print(f"Failures: {failures:,} ({failures / len(data):.2%})")
    print(f"Multi-failure rows: {int(data['is_multi_failure'].sum()):,}")
    print("\nFailure rate by product type:")
    print(
        tables["type_failure_summary"][
            ["Type", "rows", "failures", "failure_rate_pct"]
        ].to_string(index=False, formatters={"failure_rate_pct": "{:.2f}".format})
    )
    print("\nIQR outlier counts:")
    print(
        tables["outlier_summary"][
            ["feature", "outlier_rows", "outlier_rate_pct"]
        ].to_string(index=False, formatters={"outlier_rate_pct": "{:.2f}".format})
    )
    print("\nNumeric association with Machine failure (Spearman):")
    print(
        tables["target_association"].to_string(
            index=False,
            formatters={"spearman_with_machine_failure": "{:.3f}".format},
        )
    )
    product_prefix_matches_type = data["Product ID"].str[0].eq(data["Type"]).all()
    print(f"\nProduct ID prefix always equals Type: {product_prefix_matches_type}")
    print("Model inputs: " + ", ".join(MODEL_FEATURES))
    print(
        "Excluded from inputs: UDI, Product ID, failure labels, "
        "and fields derived from failure labels"
    )
    print(f"\nSummary tables written to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="EDA for the cleaned AI4I data.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = load_cleaned_data(args.input.resolve())
    validate_cleaned_data(data)
    tables = build_summary_tables(data)
    save_summary_tables(tables, args.output_dir.resolve())
    save_figures(data, tables, args.output_dir.resolve())
    print_key_results(data, tables, args.output_dir.resolve())


if __name__ == "__main__":
    main()
