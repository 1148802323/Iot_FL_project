from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL_DIR = PROJECT_ROOT / "data" / "model"
DEFAULT_FEDERATED_DIR = PROJECT_ROOT / "data" / "federated"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "outputs" / "centralized_baseline"
TARGET = "Machine failure"
NUMERIC_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]


def load_dataset(
    model_dir: Path,
    federated_dir: Path,
) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series, pd.Series]:
    features = pd.read_csv(model_dir / "ai4i_features.csv")
    labels = pd.read_csv(model_dir / "ai4i_labels.csv")
    split = pd.read_csv(federated_dir / "global_split_assignment.csv")

    if not features["sample_id"].equals(labels["sample_id"]):
        raise ValueError("Feature and label tables are not aligned")

    data = features.merge(labels[["sample_id", TARGET]], on="sample_id")
    data = data.merge(split, on="sample_id", validate="one_to_one")
    feature_columns = [column for column in features.columns if column != "sample_id"]

    train = data[data["split"].eq("train")].copy()
    test = data[data["split"].eq("global_test")].copy()
    if set(train["sample_id"]).intersection(test["sample_id"]):
        raise ValueError("Training and global-test sets overlap")

    return (
        train[feature_columns],
        train[TARGET],
        test[feature_columns],
        test[TARGET],
        test["sample_id"],
    )


def build_pipeline(
    feature_columns: list[str],
    class_weight: str | None,
    seed: int,
) -> Pipeline:
    categorical_features = [
        column for column in feature_columns if column not in NUMERIC_FEATURES
    ]
    preprocessing = ColumnTransformer(
        [
            ("numeric", StandardScaler(), NUMERIC_FEATURES),
            ("categorical", "passthrough", categorical_features),
        ],
        verbose_feature_names_out=False,
    )
    classifier = LogisticRegression(
        class_weight=class_weight,
        max_iter=2_000,
        random_state=seed,
    )
    return Pipeline(
        [
            ("preprocessing", preprocessing),
            ("classifier", classifier),
        ]
    )


def classification_metrics(
    y_true: pd.Series | np.ndarray,
    probabilities: np.ndarray,
    threshold: float,
) -> dict[str, float | int]:
    predictions = (probabilities >= threshold).astype("int8")
    tn, fp, fn, tp = confusion_matrix(y_true, predictions, labels=[0, 1]).ravel()
    return {
        "threshold": float(threshold),
        "accuracy": float(accuracy_score(y_true, predictions)),
        "precision": float(
            precision_score(y_true, predictions, zero_division=0)
        ),
        "recall": float(recall_score(y_true, predictions, zero_division=0)),
        "f1": float(f1_score(y_true, predictions, zero_division=0)),
        "pr_auc_average_precision": float(
            average_precision_score(y_true, probabilities)
        ),
        "roc_auc": float(roc_auc_score(y_true, probabilities)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def find_best_threshold(
    y_true: pd.Series,
    probabilities: np.ndarray,
) -> tuple[float, pd.DataFrame]:
    rows = [
        classification_metrics(y_true, probabilities, threshold)
        for threshold in np.linspace(0.05, 0.95, 91)
    ]
    table = pd.DataFrame(rows)
    best = table.sort_values(
        ["f1", "recall", "precision"],
        ascending=False,
    ).iloc[0]
    return float(best["threshold"]), table


def save_test_figure(
    y_true: pd.Series,
    probabilities: np.ndarray,
    threshold: float,
    output_path: Path,
) -> None:
    predictions = (probabilities >= threshold).astype("int8")
    precision, recall, _ = precision_recall_curve(y_true, probabilities)

    figure, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].plot(recall, precision, color="#2457A6", linewidth=2)
    axes[0].axhline(
        y_true.mean(),
        color="#6B7280",
        linestyle="--",
        label=f"Failure prevalence ({y_true.mean():.2%})",
    )
    axes[0].set_title("Precision–recall curve — global test set")
    axes[0].set_xlabel("Recall")
    axes[0].set_ylabel("Precision")
    axes[0].legend()

    ConfusionMatrixDisplay.from_predictions(
        y_true,
        predictions,
        labels=[0, 1],
        display_labels=["Normal", "Failure"],
        cmap="Blues",
        colorbar=False,
        ax=axes[1],
    )
    axes[1].set_title(f"Confusion matrix — threshold {threshold:.2f}")
    figure.tight_layout()
    figure.savefig(output_path, dpi=160)
    plt.close(figure)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train a centralized logistic-regression baseline."
    )
    parser.add_argument("--model-dir", type=Path, default=DEFAULT_MODEL_DIR)
    parser.add_argument(
        "--federated-dir",
        type=Path,
        default=DEFAULT_FEDERATED_DIR,
    )
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--validation-fraction", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    x_train_full, y_train_full, x_test, y_test, test_ids = load_dataset(
        args.model_dir.resolve(),
        args.federated_dir.resolve(),
    )
    x_train, x_validation, y_train, y_validation = train_test_split(
        x_train_full,
        y_train_full,
        test_size=args.validation_fraction,
        stratify=y_train_full,
        random_state=args.seed,
    )

    candidates = {
        "unweighted": None,
        "class_weight_balanced": "balanced",
    }
    validation_rows = []
    threshold_tables = []
    for name, class_weight in candidates.items():
        pipeline = build_pipeline(
            list(x_train.columns),
            class_weight,
            args.seed,
        )
        pipeline.fit(x_train, y_train)
        validation_probability = pipeline.predict_proba(x_validation)[:, 1]
        threshold, threshold_table = find_best_threshold(
            y_validation,
            validation_probability,
        )
        best_metrics = classification_metrics(
            y_validation,
            validation_probability,
            threshold,
        )
        validation_rows.append({"model": name, **best_metrics})
        threshold_table.insert(0, "model", name)
        threshold_tables.append(threshold_table)

    validation_summary = pd.DataFrame(validation_rows).sort_values(
        ["f1", "recall", "pr_auc_average_precision"],
        ascending=False,
    )
    selected = validation_summary.iloc[0]
    selected_name = str(selected["model"])
    selected_threshold = float(selected["threshold"])

    final_pipeline = build_pipeline(
        list(x_train_full.columns),
        candidates[selected_name],
        args.seed,
    )
    final_pipeline.fit(x_train_full, y_train_full)
    test_probability = final_pipeline.predict_proba(x_test)[:, 1]
    test_metrics = classification_metrics(
        y_test,
        test_probability,
        selected_threshold,
    )
    test_predictions = (test_probability >= selected_threshold).astype("int8")

    validation_summary.to_csv(
        output_dir / "validation_model_summary.csv",
        index=False,
    )
    pd.concat(threshold_tables, ignore_index=True).to_csv(
        output_dir / "validation_threshold_search.csv",
        index=False,
    )
    pd.DataFrame(
        {
            "sample_id": test_ids.to_numpy(),
            "y_true": y_test.to_numpy(),
            "y_probability": test_probability,
            "y_pred": test_predictions,
        }
    ).to_csv(output_dir / "global_test_predictions.csv", index=False)

    result = {
        "selected_model": selected_name,
        "selection_source": "validation set only",
        "selected_threshold": selected_threshold,
        "train_rows": len(x_train_full),
        "validation_rows_for_selection": len(x_validation),
        "global_test_rows": len(x_test),
        "test_metrics": test_metrics,
    }
    (output_dir / "metrics.json").write_text(
        json.dumps(result, indent=2) + "\n",
        encoding="utf-8",
    )
    joblib.dump(final_pipeline, output_dir / "model.joblib")
    save_test_figure(
        y_test,
        test_probability,
        selected_threshold,
        output_dir / "global_test_evaluation.png",
    )

    print("Validation candidates:")
    print(
        validation_summary[
            [
                "model",
                "threshold",
                "precision",
                "recall",
                "f1",
                "pr_auc_average_precision",
            ]
        ].to_string(index=False, float_format=lambda value: f"{value:.4f}")
    )
    print(f"\nSelected model: {selected_name}")
    print(f"Selected threshold: {selected_threshold:.2f}")
    print("\nGlobal-test metrics:")
    for name in [
        "accuracy",
        "precision",
        "recall",
        "f1",
        "pr_auc_average_precision",
        "roc_auc",
    ]:
        print(f"{name}: {test_metrics[name]:.4f}")
    print(
        "Confusion matrix: "
        f"TN={test_metrics['tn']}, FP={test_metrics['fp']}, "
        f"FN={test_metrics['fn']}, TP={test_metrics['tp']}"
    )
    print(f"\nOutputs written to: {output_dir}")


if __name__ == "__main__":
    main()
