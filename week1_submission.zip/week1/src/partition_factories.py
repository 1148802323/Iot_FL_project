from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MODEL_DIR = PROJECT_ROOT / "data" / "model"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "data" / "federated"
TYPE_FEATURES = ["Type_H", "Type_L", "Type_M"]
FAILURE_MODES = ["TWF", "HDF", "PWF", "OSF", "RNF"]
TARGET = "Machine failure"


def load_model_tables(model_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    features_path = model_dir / "ai4i_features.csv"
    labels_path = model_dir / "ai4i_labels.csv"
    if not features_path.exists() or not labels_path.exists():
        raise FileNotFoundError(
            "Model tables are missing. "
            "Run `uv run python src/build_model_dataset.py` first."
        )

    features = pd.read_csv(features_path)
    labels = pd.read_csv(labels_path)
    if not features["sample_id"].equals(labels["sample_id"]):
        raise ValueError("Feature and label tables are not aligned")
    return features, labels


def product_type(features: pd.DataFrame) -> pd.Series:
    encoded = features[TYPE_FEATURES]
    if not encoded.sum(axis=1).eq(1).all():
        raise ValueError("Invalid product-type one-hot encoding")
    return encoded.idxmax(axis=1).str.removeprefix("Type_")


def stratified_train_test_ids(
    features: pd.DataFrame,
    labels: pd.DataFrame,
    test_fraction: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    strata = pd.DataFrame(
        {
            "sample_id": features["sample_id"],
            "Type": product_type(features),
            TARGET: labels[TARGET],
        }
    )
    train_ids: list[int] = []
    test_ids: list[int] = []

    for _, group in strata.groupby(["Type", TARGET], sort=True):
        ids = group["sample_id"].to_numpy(copy=True)
        rng.shuffle(ids)
        test_count = max(1, int(round(len(ids) * test_fraction)))
        test_ids.extend(ids[:test_count].tolist())
        train_ids.extend(ids[test_count:].tolist())

    return np.array(sorted(train_ids)), np.array(sorted(test_ids))


def build_partition_frame(
    train_features: pd.DataFrame,
    train_labels: pd.DataFrame,
) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "sample_id": train_features["sample_id"],
            "Type": product_type(train_features),
            TARGET: train_labels[TARGET],
            "failure_modes": train_labels["failure_modes"],
        }
    )


def iid_assignment(
    partition_frame: pd.DataFrame,
    n_clients: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    assignments: list[dict[str, int | str]] = []
    strata = ["Type", "failure_modes"]

    for _, group in partition_frame.groupby(strata, sort=True):
        ids = group["sample_id"].to_numpy(copy=True)
        rng.shuffle(ids)
        client_order = rng.permutation(n_clients)
        for split_index, client_ids in enumerate(np.array_split(ids, n_clients)):
            client_index = int(client_order[split_index])
            assignments.extend(
                {
                    "sample_id": int(sample_id),
                    "factory": f"factory_{client_index + 1:02d}",
                }
                for sample_id in client_ids
            )

    return pd.DataFrame(assignments).sort_values("sample_id").reset_index(drop=True)


def dirichlet_assignment(
    partition_frame: pd.DataFrame,
    n_clients: int,
    alpha: float,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    assignments: list[dict[str, int | str]] = []
    strata = ["Type", "failure_modes"]

    for _, group in partition_frame.groupby(strata, sort=True):
        ids = group["sample_id"].to_numpy(copy=True)
        rng.shuffle(ids)
        proportions = rng.dirichlet(np.full(n_clients, alpha))
        counts = rng.multinomial(len(ids), proportions)
        start = 0
        for client_index, count in enumerate(counts):
            client_ids = ids[start : start + count]
            assignments.extend(
                {
                    "sample_id": int(sample_id),
                    "factory": f"factory_{client_index + 1:02d}",
                }
                for sample_id in client_ids
            )
            start += count

    return pd.DataFrame(assignments).sort_values("sample_id").reset_index(drop=True)


def validate_assignment(
    assignment: pd.DataFrame,
    train_ids: np.ndarray,
    n_clients: int,
    strategy: str,
) -> None:
    if len(assignment) != len(train_ids):
        raise ValueError(f"{strategy}: row count changed during partitioning")
    if assignment["sample_id"].duplicated().any():
        raise ValueError(f"{strategy}: a sample was assigned more than once")
    if set(assignment["sample_id"]) != set(train_ids):
        raise ValueError(f"{strategy}: assignment lost or added samples")
    if assignment["factory"].nunique() != n_clients:
        raise ValueError(f"{strategy}: one or more factories are empty")


def validate_global_split(
    all_ids: pd.Series,
    train_ids: np.ndarray,
    test_ids: np.ndarray,
) -> None:
    train_set = set(train_ids)
    test_set = set(test_ids)
    if train_set.intersection(test_set):
        raise ValueError("Training and global-test sets overlap")
    if train_set.union(test_set) != set(all_ids):
        raise ValueError("Training/global-test split lost or added samples")


def export_global_test(
    features: pd.DataFrame,
    labels: pd.DataFrame,
    test_ids: np.ndarray,
    output_dir: Path,
) -> None:
    test_id_set = set(test_ids)
    test_features = features[features["sample_id"].isin(test_id_set)].copy()
    test_labels = labels[labels["sample_id"].isin(test_id_set)].copy()
    test_features.to_csv(output_dir / "global_test_features.csv", index=False)
    test_labels.to_csv(output_dir / "global_test_labels.csv", index=False)


def export_factories(
    strategy: str,
    assignment: pd.DataFrame,
    features: pd.DataFrame,
    labels: pd.DataFrame,
    output_dir: Path,
) -> list[dict[str, int | float | str]]:
    strategy_dir = output_dir / strategy
    strategy_dir.mkdir(parents=True, exist_ok=True)
    assignment.to_csv(strategy_dir / "assignment.csv", index=False)

    summary_rows: list[dict[str, int | float | str]] = []
    for factory, factory_assignment in assignment.groupby("factory", sort=True):
        ids = set(factory_assignment["sample_id"])
        client_features = features[features["sample_id"].isin(ids)].copy()
        client_labels = labels[labels["sample_id"].isin(ids)].copy()
        client_features.to_csv(
            strategy_dir / f"{factory}_features.csv", index=False
        )
        client_labels.to_csv(
            strategy_dir / f"{factory}_labels.csv", index=False
        )

        row: dict[str, int | float | str] = {
            "strategy": strategy,
            "factory": factory,
            "rows": len(client_labels),
            "failures": int(client_labels[TARGET].sum()),
            "failure_rate_pct": client_labels[TARGET].mean() * 100,
            "multi_failure_rows": int(client_labels["is_multi_failure"].sum()),
        }
        for type_column in TYPE_FEATURES:
            row[type_column] = int(client_features[type_column].sum())
        for mode in FAILURE_MODES:
            row[mode] = int(client_labels[mode].sum())
        summary_rows.append(row)
    return summary_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create IID and Non-IID AI4I factory partitions."
    )
    parser.add_argument("--model-dir", type=Path, default=DEFAULT_MODEL_DIR)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--clients", type=int, default=5)
    parser.add_argument("--test-fraction", type=float, default=0.20)
    parser.add_argument("--moderate-alpha", type=float, default=5.0)
    parser.add_argument("--high-alpha", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    model_dir = args.model_dir.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    features, labels = load_model_tables(model_dir)
    train_ids, test_ids = stratified_train_test_ids(
        features, labels, args.test_fraction, args.seed
    )
    validate_global_split(features["sample_id"], train_ids, test_ids)
    train_id_set = set(train_ids)
    train_features = features[features["sample_id"].isin(train_id_set)].copy()
    train_labels = labels[labels["sample_id"].isin(train_id_set)].copy()
    partition_frame = build_partition_frame(train_features, train_labels)

    assignments = {
        "iid": iid_assignment(partition_frame, args.clients, args.seed + 1),
        "moderate_non_iid": dirichlet_assignment(
            partition_frame,
            args.clients,
            args.moderate_alpha,
            args.seed + 2,
        ),
        "high_non_iid": dirichlet_assignment(
            partition_frame,
            args.clients,
            args.high_alpha,
            args.seed + 3,
        ),
    }

    export_global_test(features, labels, test_ids, output_dir)
    summary_rows: list[dict[str, int | float | str]] = []
    for strategy, assignment in assignments.items():
        validate_assignment(assignment, train_ids, args.clients, strategy)
        summary_rows.extend(
            export_factories(
                strategy,
                assignment,
                train_features,
                train_labels,
                output_dir,
            )
        )

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(output_dir / "factory_summary.csv", index=False)

    split_assignment = pd.DataFrame(
        {
            "sample_id": [*train_ids, *test_ids],
            "split": ["train"] * len(train_ids) + ["global_test"] * len(test_ids),
        }
    ).sort_values("sample_id")
    split_assignment.to_csv(output_dir / "global_split_assignment.csv", index=False)

    label_lookup = labels.set_index("sample_id")[TARGET]
    split_summary_rows = []
    for split_name, ids in [("train", train_ids), ("global_test", test_ids)]:
        split_labels = label_lookup.loc[ids]
        split_summary_rows.append(
            {
                "split": split_name,
                "rows": len(ids),
                "failures": int(split_labels.sum()),
                "failure_rate_pct": split_labels.mean() * 100,
            }
        )
    split_summary = pd.DataFrame(split_summary_rows)
    split_summary.to_csv(output_dir / "global_split_summary.csv", index=False)

    config = {
        "clients": args.clients,
        "test_fraction": args.test_fraction,
        "moderate_dirichlet_alpha": args.moderate_alpha,
        "high_dirichlet_alpha": args.high_alpha,
        "seed": args.seed,
        "partition_strata": ["Type", "failure_modes"],
        "single_factory_per_sample_per_strategy": True,
        "standardized": False,
    }
    (output_dir / "partition_config.json").write_text(
        json.dumps(config, indent=2) + "\n",
        encoding="utf-8",
    )

    print(f"Training rows assigned to factories: {len(train_ids):,}")
    print(f"Global test rows held out: {len(test_ids):,}")
    print(f"Factories per strategy: {args.clients}")
    print(
        f"Global test failures: {int(label_lookup.loc[test_ids].sum()):,} "
        f"({label_lookup.loc[test_ids].mean():.2%})"
    )
    print("\nFactory summary:")
    print(
        summary[
            ["strategy", "factory", "rows", "failures", "failure_rate_pct"]
        ].to_string(
            index=False,
            formatters={"failure_rate_pct": "{:.2f}".format},
        )
    )
    print(f"\nOutputs written to: {output_dir}")


if __name__ == "__main__":
    main()
